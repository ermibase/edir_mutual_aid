import { Stack } from "expo-router";

export default function AuthLayout() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="login" options={{ title: "false" }} />
      <Stack.Screen name="sign-up" options={{ title: "false" }} />
      <Stack.Screen name="welcome" options={{ title: "false" }} />
      <Stack.Screen name="forgot-password" options={{ title: "false" }} />
    </Stack>
  );
}