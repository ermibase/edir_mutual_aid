import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { useTranslation } from 'react-i18next';
import { apiCall } from '../../../src/utils/api';

export default function ForgotPassword() {
  const { edirSlug } = useLocalSearchParams();
  const { t } = useTranslation();
  const [email, setEmail] = useState('');
  const [token, setToken] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isResetRequested, setIsResetRequested] = useState(false);

  const handleRequestReset = async () => {
    if (!email) {
      Alert.alert(t('enterEmail'));
      return;
    }

    try {
      await apiCall(`/api/${edirSlug}/members/request-password-reset/`, 'POST', { email });
      Alert.alert(t('resetPasswordSent'), t('enterTokenAndPassword'));
      setIsResetRequested(true);
    } catch (error) {
      console.error('Password reset request error:', error);
      Alert.alert(t('resetPasswordFailed'), error.message || t('errorOccurred'));
    }
  };

  const handleSubmitNewPassword = async () => {
    if (!token || !password || !confirmPassword) {
      Alert.alert(t('enterAllFields'));
      return;
    }

    if (password !== confirmPassword) {
      Alert.alert(t('passwordsDoNotMatch'));
      return;
    }

    try {
      await apiCall(`/api/${edirSlug}/members/reset-password/`, 'POST', {
        password,
        token,
      });
      Alert.alert(t('passwordResetSuccess'), t('loginWithNewPassword'));
      setIsResetRequested(false);
      setEmail('');
      setToken('');
      setPassword('');
      setConfirmPassword('');
    } catch (error) {
      console.error('Password reset error:', error);
      Alert.alert(t('passwordResetFailed'), error.message || t('errorOccurred'));
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>
        {isResetRequested ? t('resetPasswordTitle') : t('forgotPasswordTitle')}
      </Text>
      {!isResetRequested ? (
        <>
          <TextInput
            style={styles.input}
            placeholder={t('email')}
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />
          <TouchableOpacity style={styles.resetButton} onPress={handleRequestReset}>
            <Text style={styles.resetButtonText}>{t('sendResetLink')}</Text>
          </TouchableOpacity>
        </>
      ) : (
        <>
          <TextInput
            style={styles.input}
            placeholder={t('resetToken')}
            value={token}
            onChangeText={setToken}
            autoCapitalize="none"
          />
          <TextInput
            style={styles.input}
            placeholder={t('newPassword')}
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            autoCapitalize="none"
          />
          <TextInput
            style={styles.input}
            placeholder={t('confirmPassword')}
            value={confirmPassword}
            onChangeText={setConfirmPassword}
            secureTextEntry
            autoCapitalize="none"
          />
          <TouchableOpacity style={styles.resetButton} onPress={handleSubmitNewPassword}>
            <Text style={styles.resetButtonText}>{t('submitNewPassword')}</Text>
          </TouchableOpacity>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#1B4332',
  },
  title: {
    fontSize: 20,
    marginBottom: 20,
    color: '#D3D3D3',
  },
  input: {
    width: '100%',
    padding: 10,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    backgroundColor: '#fff',
  },
  resetButton: {
    backgroundColor: '#233428',
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 5,
    marginTop: 20,
  },
  resetButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});