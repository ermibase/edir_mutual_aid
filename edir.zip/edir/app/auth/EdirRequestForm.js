import React, { useState } from 'react'; 
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Platform, ScrollView, Alert as RNAlert, Button } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import { apiCall } from '../../src/utils/api';

export default function EdirRequestForm() {
  const [edirName, setEdirName] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [proposedCbeAccount, setProposedCbeAccount] = useState('');
  const [proposedAccountHolder, setProposedAccountHolder] = useState('');
  const [proposedAddress, setProposedAddress] = useState('');
  const [proposedInitialDeposit, setProposedInitialDeposit] = useState('');
  const [pdfFile, setPdfFile] = useState(null);

  const showAlert = (title, message) => {
    if (Platform.OS === 'web') {
      alert(`${title ? title + '\n' : ''}${message}`);
    } else {
      RNAlert.alert(title || '', message);
    }
  };

  const handlePickPdf = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({ type: 'application/pdf' });
      if (result.type === 'success') {
        setPdfFile(result);
      }
    } catch (err) {
      console.error('Error picking PDF:', err);
    }
  };

  const handleSubmit = async () => {
    try {
      const requestData = {
        full_name: fullName,
        username: username,
        email: email,
        password: password,
        edir_name: edirName,
        edir_description: description,
        location: location,
        proposed_cbe_account: proposedCbeAccount,
        proposed_account_holder: proposedAccountHolder,
        proposed_address: proposedAddress,
        proposed_initial_deposit: Number(proposedInitialDeposit),
        // pdfFile will be handled separately if uploading is needed
      };

      console.log('Submitting request:', requestData);

      const response = await apiCall('/api/edir/requests/', 'POST', requestData);

      console.log('Success:', response);
      showAlert('Success', 'Your Edir request has been submitted.');

      // Clear form
      setFullName('');
      setUsername('');
      setEmail('');
      setPassword('');
      setEdirName('');
      setDescription('');
      setLocation('');
      setProposedCbeAccount('');
      setProposedAccountHolder('');
      setProposedAddress('');
      setProposedInitialDeposit('');
      setPdfFile(null);

    } catch (error) {
      console.error('Network error:', error);
      showAlert('Error', error.message || 'Something went wrong');
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 40 }}>
      <Text style={styles.header}>Edir Registration Request Form</Text>
      <Text style={styles.subText}>Create your community in minutes</Text>
      <Text style={styles.note}>
        Note: After your request is approved, you will be assigned as the head of this Edir. Please make sure you are ready to lead and manage your community.
      </Text>

      <View style={styles.inputContainer}>
        <TextInput
          placeholder="Full Name (e.g., Abebe Kebede)"
          placeholderTextColor="#888888"
          style={styles.input}
          value={fullName}
          onChangeText={setFullName}
        />
      </View>
      <View style={styles.inputContainer}>
        <TextInput
          placeholder="Username (e.g., @abebekebede)"
          placeholderTextColor="#888888"
          style={styles.input}
          value={username}
          onChangeText={setUsername}
        />
      </View>
      <View style={styles.inputContainer}>
        <TextInput
          placeholder="Email Address (e.g., abebe@email.com)"
          placeholderTextColor="#888888"
          style={styles.input}
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
        />
      </View>
      <View style={styles.inputContainer}>
        <TextInput
          placeholder="Password (At least 8 chars, upper, lower, number, special char)"
          placeholderTextColor="#888888"
          style={styles.input}
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />
      </View>

      <View style={styles.inputContainer}>
        <TextInput
          placeholder="Edir Name (e.g., My Edir Community)"
          placeholderTextColor="#888888"
          style={styles.input}
          value={edirName}
          onChangeText={setEdirName}
        />
      </View>
      <View style={styles.inputContainer}>
        <TextInput
          placeholder="Location"
          placeholderTextColor="#888888"
          style={styles.input}
          value={location}
          onChangeText={setLocation}
        />
      </View>
      <View style={[styles.inputContainer, { height: 100 }]}>
        <TextInput
          placeholder="Description (Describe your Edir community purpose...)"
          placeholderTextColor="#888888"
          style={[styles.input, { height: '100%', textAlignVertical: 'top' }]}
          multiline
          value={description}
          onChangeText={setDescription}
        />
      </View>

      <View style={styles.inputContainer}>
        <TextInput
          placeholder="Proposed CBE Account"
          placeholderTextColor="#888888"
          style={styles.input}
          value={proposedCbeAccount}
          onChangeText={setProposedCbeAccount}
        />
      </View>
      <View style={styles.inputContainer}>
        <TextInput
          placeholder="Proposed Account Holder"
          placeholderTextColor="#888888"
          style={styles.input}
          value={proposedAccountHolder}
          onChangeText={setProposedAccountHolder}
        />
      </View>
      <View style={styles.inputContainer}>
        <TextInput
          placeholder="Proposed Address"
          placeholderTextColor="#888888"
          style={styles.input}
          value={proposedAddress}
          onChangeText={setProposedAddress}
        />
      </View>
      <View style={styles.inputContainer}>
        <TextInput
          placeholder="Proposed Initial Deposit"
          placeholderTextColor="#888888"
          style={styles.input}
          value={proposedInitialDeposit}
          onChangeText={setProposedInitialDeposit}
          keyboardType="numeric"
        />
      </View>

      <TouchableOpacity style={styles.button} onPress={handlePickPdf}>
        <Text style={styles.buttonText}>{pdfFile ? 'PDF Selected' : 'Add PDF'}</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.button} onPress={handleSubmit}>
        <Text style={styles.buttonText}>Submit Request</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    padding: 20,
  },
  header: {
    fontSize: 22,
    color: 'black',
    fontWeight: 'bold',
    marginBottom: 5,
    marginTop:20,
  },
  subText: {
    fontSize: 16,
    color: '#333333',
    marginBottom: 10,
  },
  note: {
    fontSize: 14,
    color: '#333333',
    marginBottom: 20,
  },
  inputContainer: {
    borderWidth: 1,
    borderColor: '#B2BEB5',
    borderRadius: 5,
    width: '100%',
    backgroundColor: '#fff',
    marginBottom: 10,
    overflow: 'hidden',
  },
  input: {
    color: '#000',
    height: 55,
    width: '100%',
    fontSize: 14,
    paddingHorizontal: 10,
    
  },
  button: {
    backgroundColor: '#23A032',
   borderRadius: 5,
    paddingVertical: 10,
    alignSelf: 'center',
    width: '100%',
    alignItems: 'center',
    marginBottom: 5,
    marginTop:20,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
