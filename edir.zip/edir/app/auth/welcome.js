import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  Animated,
  Dimensions,
  ScrollView,
  Platform,
  TextInput,
  ImageBackground,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useRouter } from 'expo-router';
import { useTranslation } from 'react-i18next';
import '../../src/i18n';

const { width, height } = Dimensions.get('window');

export default function WelcomeScreen() {
  const [selectedAssociation, setSelectedAssociation] = useState('');
  const [recentEdirs, setRecentEdirs] = useState([]);
  const router = useRouter();
  const { t } = useTranslation();

  // Animation refs
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const handleCreateLinkPress = () => {
    router.push('/auth/EdirRequestForm');
  };

  useEffect(() => {
    const loadRecentEdirs = async () => {
      try {
        const storedEdirs = await AsyncStorage.getItem('recentEdirs');
        if (storedEdirs) {
          const parsed = JSON.parse(storedEdirs);
          setRecentEdirs(parsed);
          if (parsed.length > 0) {
            setSelectedAssociation(parsed[0]); // Auto-fill last used Edir
          }
        }
      } catch (error) {
        console.error('Error loading recent Edirs:', error);
      }
    };

    loadRecentEdirs();

    // Start animation
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 800,
      useNativeDriver: true,
    }).start();
  }, []);

  const saveEdir = async (edirSlug) => {
    try {
      const updatedEdirs = [edirSlug, ...recentEdirs.filter(e => e !== edirSlug)].slice(0, 5);
      setRecentEdirs(updatedEdirs);
      await AsyncStorage.setItem('recentEdirs', JSON.stringify(updatedEdirs));
    } catch (error) {
      console.error('Error saving Edir:', error);
    }
  };

  const handleLogin = () => {
    if (!selectedAssociation.trim()) {
      alert(t('enterEdirAlert'));
      return;
    }
    const edirSlug = selectedAssociation.trim();
    saveEdir(edirSlug);
    router.push(`/auth/login/${edirSlug}`);
  };

  const handleRegister = () => {
    if (!selectedAssociation.trim()) {
      alert(t('enterEdirAlert'));
      return;
    }
    const edirSlug = selectedAssociation.trim();
    saveEdir(edirSlug);
    router.push(`/auth/sign-up/${edirSlug}/register`);
  };

  return (
    <Animated.View style={{ flex: 1, opacity: fadeAnim }}>
      <ImageBackground
        source={require('../../assets/images/as-a-team.jpg')}
        style={styles.backgroundImage}
        imageStyle={styles.imageStyle}
      >
        <ScrollView contentContainerStyle={styles.container}>
          <View style={styles.overlay}>
            <View style={styles.header}>
              <Text style={styles.welcomeText}>{t('descriptiony')}</Text>
              <Text style={styles.subtitle}>{t('titleee')}</Text>
            </View>

            <View style={styles.formContainer}>
              <TextInput
                style={styles.input}
                placeholder={t('enterEdir')}
                placeholderTextColor="#888"
                value={selectedAssociation}
                onChangeText={setSelectedAssociation}
                autoCapitalize="none"
              />

              <TouchableOpacity style={styles.registerButton} onPress={handleRegister}>
                <Text style={styles.registerText}>{t('register')}</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
                <Text style={styles.loginText}>{t('login')}</Text>
              </TouchableOpacity>

              <View style={styles.createLinkContainer}>
                <Text style={styles.createLinkText}>Don't see your association? </Text>
                <TouchableOpacity onPress={handleCreateLinkPress}>
                  <Text style={styles.createLink}>Create one.</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </ScrollView>
      </ImageBackground>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  imageStyle: {
    opacity: 0.6, // Dim the background image
    backgroundColor: '#228B22', // Fallback color that blends with the image
  },
  container: {
    flexGrow: 1,
    padding: 20,
    paddingTop: Platform.OS === 'web' ? 40 : 60,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.3)', // Semi-transparent overlay for better text readability
    borderRadius: 10,
    padding: 20,
  },
  header: {
    marginBottom: 60,
  },
  welcomeText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
    marginBottom: 10,
    marginTop:100,
    textShadowColor: 'rgba(0,0,0,0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  subtitle: {
    fontSize: 18,
    color: '#fff',
    textAlign: 'center',
    textShadowColor: 'rgba(0,0,0,0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  formContainer: {
    marginBottom: 20,
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.9)',
    borderRadius: 10,
    padding: 15,
    marginBottom: 20,
    fontSize: 16,
    color: '#000',
  },
  registerButton: {
    backgroundColor: '#E6BE00',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginBottom: 15,
    
  },
  registerText: {
    color: '#000',
    fontWeight: 'bold',
    fontSize: 16,
  },
  loginButton: {
    backgroundColor: 'rgba(255,255,255,0.9)',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginBottom: 15,
  },
  loginText: {
    color: '#228B22',
    fontWeight: 'bold',
    fontSize: 16,
  },
  createLinkContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
  },
  createLinkText: {
    color: '#fff',
    fontSize: 14,
    textShadowColor: 'rgba(0,0,0,0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  createLink: {
    color: '#FFD700',
    fontSize: 14,
    fontWeight: 'bold',
    textDecorationLine: 'underline',
    textShadowColor: 'rgba(0,0,0,0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
});