import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Animated,
  ScrollView,
  Platform,
  Alert,
  Modal,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useTranslation } from 'react-i18next';
import i18n from '../../../../src/i18n';
import { FontAwesome } from '@expo/vector-icons';
import { Ionicons } from '@expo/vector-icons';

export default function SignUp() {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [gender, setGender] = useState('');
  
  const [showPassword, setShowPassword] = useState(false);
const [showConfirmPassword, setShowConfirmPassword] = useState(false);


  const router = useRouter();
  const { edirSlug } = useLocalSearchParams();
  const { t } = useTranslation();

  // Animation ref
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();
  }, [fadeAnim]);

  // Cross-platform alert function
  const showAlert = (message) => {
    if (Platform.OS === 'web') {
      window.alert(message); // Use browser alert for web
    } else {
      Alert.alert(message); // Use React Native Alert for mobile
    }
  };

  const handleNext = () => {
    // Trim inputs to avoid accepting whitespace as valid input
    const fields = {
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      username: username.trim(),
      email: email.trim(),
      password: password.trim(),
      confirmPassword: confirmPassword.trim(),
      phoneNumber: phoneNumber.trim(),
      gender: gender.trim(),
    };

    // Check if any field is empty
    const emptyFields = Object.entries(fields).filter(([_, value]) => !value);
    if (emptyFields.length > 0) {
      showAlert(t('pleaseFillAllFields')); // Show "Please fill all required fields" message
      return;
    }

    // Passwords must match
    if (password !== confirmPassword) {
      showAlert(t('passwordMismatch'));
      return;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      showAlert(t('invalidEmail'));
      return;
    }

    // All good: Prepare and navigate
    const formData = {
      firstName: fields.firstName,
      lastName: fields.lastName,
      username: fields.username,
      email: fields.email,
      password,
      phoneNumber: fields.phoneNumber,
      gender,
      edir: edirSlug,
      registration_type: 'member',
    };

    // Navigate to family form page with form data
    router.push({
      pathname: `/auth/sign-up/${edirSlug}/family`,
      params: { formData: JSON.stringify(formData) },
    });
  };

  

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Animated.View style={[styles.formContainer, { opacity: fadeAnim }]}>
          <Text style={styles.title}>{t('signUpTitle')}</Text>

          {/* First Name */}
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder={t('firstName')}
              placeholderTextColor="#888888"
              value={firstName}
              onChangeText={setFirstName}
              required
            />
          </View>

          {/* Last Name */}
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder={t('lastName')}
              placeholderTextColor="#888888"
              value={lastName}
              onChangeText={setLastName}
              required
            />
          </View>

          {/* Username */}
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder={t('username')}
              placeholderTextColor="#888888"
              value={username}
              onChangeText={setUsername}
              autoCapitalize="none"
              required
            />
          </View>

          {/* Email */}
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder={t('email')}
              placeholderTextColor="#888888"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              required
            />
          </View>
{/* Password */}
<View style={styles.inputContainer}>
  <View style={styles.passwordWrapper}>
    <TextInput
      style={[styles.input, { flex: 1 }]}
      placeholder={t('password')}
      placeholderTextColor="#888888"
      value={password}
      onChangeText={setPassword}
      secureTextEntry={!showPassword}
      autoCapitalize="none"
      required
    />
    <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.iconTouchable}>
<Ionicons
            name={showPassword ? 'eye-off-outline' : 'eye-outline'}
            size={22}
            color="#888888"
          />
    </TouchableOpacity>
  </View>
</View>

{/* Confirm Password */}
<View style={styles.inputContainer}>
  <View style={styles.passwordWrapper}>
    <TextInput
      style={[styles.input, { flex: 1 }]}
      placeholder={t('confirmPassword')}
      placeholderTextColor="#888888"
      value={confirmPassword}
      onChangeText={setConfirmPassword}
      secureTextEntry={!showConfirmPassword}
      autoCapitalize="none"
      required
    />
    <TouchableOpacity onPress={() => setShowConfirmPassword(!showConfirmPassword)} style={styles.iconTouchable}>
      <Ionicons
            name={showPassword ? 'eye-off-outline' : 'eye-outline'}
            size={22}
            color="#888888"
          />
    </TouchableOpacity>
  </View>
</View>


          {/* Phone Number */}
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder={t('phoneNumber')}
              placeholderTextColor="#888888"
              value={phoneNumber}
              onChangeText={setPhoneNumber}
              keyboardType="phone-pad"
              required
            />
          </View>

          {/* Gender */}
          <View style={styles.inputContainer}>
            <Picker
              selectedValue={gender}
              onValueChange={(itemValue) => setGender(itemValue)}
              style={styles.picker}
              dropdownIconColor="#BCBFB5"
            >
              <Picker.Item label={t('selectGender')} value="" />
              <Picker.Item label={t('male')} value="MALE" />
              <Picker.Item label={t('female')} value="FEMALE" />
            </Picker>
          </View>

   


          {/* Next Button */}
          <TouchableOpacity style={styles.nextButton} onPress={handleNext}>
            <Text style={styles.buttonText}>{t('next')}</Text>
          </TouchableOpacity>
        </Animated.View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  scrollContent: {
    padding: 20,
    paddingTop: Platform.OS === 'web' ? 40 : 40,
    flexGrow: 1,
    alignItems: 'center',
  },
  formContainer: {
    width: '100%',
    maxWidth: 400,
  },
  title: {
    fontSize: Platform.OS === 'web' ? 32 : 24,
    color: '#000',
    textAlign: 'center',
    fontWeight: '600',
    marginBottom: 20,
  },
  inputContainer: {
     borderWidth: 1,
    borderColor: '#B2BEB5',
    borderRadius: 5,
    width: '100%',
    backgroundColor: '#fff',
    marginBottom: 15,
    overflow: 'hidden',
  },
  input: {
    color: '#000000',
    height: 50,
    width: '100%',
    fontSize: 14,
    paddingHorizontal: 10,
  },
  picker: {
    color: '#888888',
    height: 50,
    width: '100%',
    fontSize: 12,
  },
  nextButton: {
    backgroundColor: '#23A032',
    borderRadius: 5,
    paddingVertical: 10,
    alignItems: 'center',
    alignSelf: 'center',
    width: '100%',
    bottom:-40,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  passwordWrapper: {
  flexDirection: 'row',
  alignItems: 'center',
  paddingRight: 10,
},
eyeIcon: {
  paddingLeft: 10,
  color:'#696969'
},
iconTouchable: {
  paddingLeft: 10,
  paddingVertical: 10,
},

});