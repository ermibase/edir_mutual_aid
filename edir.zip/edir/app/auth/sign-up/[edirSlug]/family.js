import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Platform,
  Alert,
  Modal,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useTranslation } from 'react-i18next';
import { apiCall } from '../../../../src/utils/api';
import { FontAwesome } from '@expo/vector-icons';

export default function FamilyForm() {
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [zipCode, setZipCode] = useState('');
  const [spouseFullName, setSpouseFullName] = useState('');
  const [spouseEmail, setSpouseEmail] = useState('');
  const [spousePhoneNumber, setSpousePhoneNumber] = useState('');
  const [familyMembers, setFamilyMembers] = useState([{ fullName: '', gender: '', dateOfBirth: '', relationship: '' }]);
  const [representatives, setRepresentatives] = useState([{ fullName: '', phoneNumber: '', email: '', dateOfDesignation: '' }]);
const [languageModalVisible, setLanguageModalVisible] = useState(false);
  const router = useRouter();
  const { edirSlug, formData } = useLocalSearchParams();
  const { t } = useTranslation();

  // Parse sign-up form data
  const signUpData = formData ? JSON.parse(formData) : {};
  console.log('Parsed SignUp Data:', signUpData); // L

  // Cross-platform alert function
  const showAlert = (title, message) => {
    if (Platform.OS === 'web') {
      window.alert(`${title}: ${message}`); // Use browser alert for web
    } else {
      Alert.alert(title, message); // Use React Native Alert for mobile
    }
  };

  const handleAddFamilyMember = () => {
    setFamilyMembers([...familyMembers, { fullName: '', gender: '', dateOfBirth: '', relationship: '' }]);
  };

  const handleAddRepresentative = () => {
    setRepresentatives([...representatives, { fullName: '', phoneNumber: '', email: '', dateOfDesignation: '' }]);
  };

  const handleFamilyMemberChange = (index, field, value) => {
    const updatedMembers = [...familyMembers];
    updatedMembers[index][field] = value;
    setFamilyMembers(updatedMembers);
  };

  const handleRepresentativeChange = (index, field, value) => {
    const updatedReps = [...representatives];
    updatedReps[index][field] = value;
    setRepresentatives(updatedReps);
  };

 const handleSubmit = async () => {
    console.log('handleSubmit called');
    if (!address || !city || !state || !zipCode) {
      showAlert(t('fillAllFields'), t('addressFieldsRequired'));
      return;
    }

    const phoneRegex = /^\+\d{10,15}$/;
    if (spouseFullName && !spousePhoneNumber) {
      showAlert(t('fillAllFields'), t('spousePhoneRequired'));
      return;
    }
    if (spousePhoneNumber && !phoneRegex.test(spousePhoneNumber)) {
      showAlert(t('invalidPhoneNumber'), t('phoneMustHaveCountryCode'));
      return;
    }

    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    for (const member of familyMembers) {
      if (member.fullName || member.gender || member.dateOfBirth || member.relationship) {
        if (!member.fullName || !member.gender || !member.dateOfBirth || !member.relationship) {
          showAlert(t('fillAllFields'), t('familyMemberFieldsRequired'));
          return;
        }
        if (member.dateOfBirth && !dateRegex.test(member.dateOfBirth)) {
          showAlert(t('invalidDateFormat'), t('dateMustBeYYYYMMDD'));
          return;
        }
        // Validate gender enum
        if (member.gender && !['MALE', 'FEMALE', 'OTHER'].includes(member.gender)) {
          showAlert(t('invalidGender'), t('genderMustBeMaleFemaleOrOther'));
          return;
        }
      }
    }

    for (const rep of representatives) {
      if (rep.fullName || rep.phoneNumber || rep.email || rep.dateOfDesignation) {
        if (!rep.fullName || !rep.phoneNumber || !rep.email || !rep.dateOfDesignation) {
          showAlert(t('fillAllFields'), t('representativeFieldsRequired'));
          return;
        }
        if (!phoneRegex.test(rep.phoneNumber)) {
          showAlert(t('invalidPhoneNumber'), t('phoneMustHaveCountryCode'));
          return;
        }
        if (rep.dateOfDesignation && !dateRegex.test(rep.dateOfDesignation)) {
          showAlert(t('invalidDateFormat'), t('dateMustBeYYYYMMDD'));
          return;
        }
      }
    }

    const requestBody = {
      username: signUpData.username,
      password: signUpData.password,
      full_name: `${signUpData.firstName} ${signUpData.lastName}`,
      email: signUpData.email,
      phone_number: signUpData.phoneNumber,
      gender: signUpData.gender,
      address,
      city,
      state,
      zip_code: zipCode,
      edir: signUpData.edir,
      registration_type: 'family', // Explicitly set to 'family' for clarity
      spouse: spouseFullName
        ? {
            full_name: spouseFullName,
            email: spouseEmail || null,
            phone_number: spousePhoneNumber,
          }
        : null,
      family_members: familyMembers
        .filter(member => member.fullName)
        .map(member => ({
          full_name: member.fullName,
          gender: member.gender,
          date_of_birth: member.dateOfBirth,
          relationship: member.relationship,
        })),
      representatives: representatives
        .filter(rep => rep.fullName)
        .map(rep => ({
          full_name: rep.fullName,
          phone_number: rep.phoneNumber,
          email: rep.email,
          date_of_designation: rep.dateOfDesignation,
        })),
    };

    console.log('Request Body:', JSON.stringify(requestBody, null, 2));

    try {
      console.log('Attempting API call to:', `/api/${edirSlug}/members/create/`);
      const response = await apiCall(`/api/${edirSlug}/members/create/`, 'POST', requestBody);
      console.log('API Response:', response);
      showAlert(t('registrationSuccess'), t('loginNow'));
      router.push(`/auth/login/${edirSlug}`);
    } catch (error) {
      console.error('API Error:', error);
      console.error('Error Response:', error.response ? error.response : 'No response data');
      showAlert(t('registrationFailed'), error.response?.detail || error.message || t('networkError'));
    }
  };
  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Text style={styles.title}>{t('familyFormTitle')}</Text>

    
        {/* Address Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('addressInfo')}</Text>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder={t('address')}
              placeholderTextColor="#888888"
              value={address}
              onChangeText={setAddress}
            />
          </View>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder={t('city')}
              placeholderTextColor="#888888"
              value={city}
              onChangeText={setCity}
            />
          </View>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder={t('state')}
              placeholderTextColor="#888888"
              value={state}
              onChangeText={setState}
            />
          </View>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder={t('zipCode')}
              placeholderTextColor="#888888"
              value={zipCode}
              onChangeText={setZipCode}
              keyboardType="numeric"
            />
          </View>
        </View>

        {/* Spouse Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('spouse')}</Text>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder={t('spouseFullName')}
              placeholderTextColor="#888888"
              value={spouseFullName}
              onChangeText={setSpouseFullName}
            />
          </View>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder={t('spouseEmail')}
              placeholderTextColor="#888888"
              value={spouseEmail}
              onChangeText={setSpouseEmail}
              keyboardType="email-address"
              autoCapitalize="none"
            />
          </View>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder={t('spousePhoneNumber')}
              placeholderTextColor="#888888"
              value={spousePhoneNumber}
              onChangeText={setSpousePhoneNumber}
              keyboardType="phone-pad"
            />
          </View>
        </View>

        {/* Family Members */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('familyMembers')}</Text>
          {familyMembers.map((member, index) => (
            <View key={index} style={styles.memberContainer}>
              <View style={styles.inputContainer}>
                <TextInput
                  style={styles.input}
                  placeholder={t('fullName')}
                  placeholderTextColor="#888888"
                  value={member.fullName}
                  onChangeText={(text) => handleFamilyMemberChange(index, 'fullName', text)}
                />
              </View>
              <View style={styles.inputContainer}>
                <Picker
                  selectedValue={member.gender}
                  onValueChange={(value) => handleFamilyMemberChange(index, 'gender', value)}
                  style={styles.picker}
                  dropdownIconColor="#888888"
                >
                  <Picker.Item label={t('selectGender')} value="" />
                  <Picker.Item label={t('male')} value="MALE" />
                  <Picker.Item label={t('female')} value="FEMALE" />
                  <Picker.Item label={t('other')} value="OTHER" />
                </Picker>
              </View>
              <View style={styles.inputContainer}>
                <TextInput
                  style={styles.input}
                  placeholder={t('dateOfBirth')}
                  placeholderTextColor="#888888"
                  value={member.dateOfBirth}
                  onChangeText={(text) => handleFamilyMemberChange(index, 'dateOfBirth', text)}
                  // Ideally, use a date picker component for better UX
                />
              </View>
              <View style={styles.inputContainer}>
                <TextInput
                  style={styles.input}
                  placeholder={t('relationship')}
                  placeholderTextColor="#888888"
                  value={member.relationship}
                  onChangeText={(text) => handleFamilyMemberChange(index, 'relationship', text)}
                />
              </View>
            </View>
          ))}
          <TouchableOpacity style={styles.addButton} onPress={handleAddFamilyMember}>
            <Text style={styles.addButtonText}>{t('addFamilyMember')}</Text>
          </TouchableOpacity>
        </View>

        {/* Representatives */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('representatives')}</Text>
          {representatives.map((rep, index) => (
            <View key={index} style={styles.memberContainer}>
              <View style={styles.inputContainer}>
                <TextInput
                  style={styles.input}
                  placeholder={t('fullName')}
                  placeholderTextColor="#888888"
                  value={rep.fullName}
                  onChangeText={(text) => handleRepresentativeChange(index, 'fullName', text)}
                />
              </View>
              <View style={styles.inputContainer}>
                <TextInput
                  style={styles.input}
                  placeholder={t('phoneNumber')}
                  placeholderTextColor="#888888"
                  value={rep.phoneNumber}
                  onChangeText={(text) => handleRepresentativeChange(index, 'phoneNumber', text)}
                  keyboardType="phone-pad"
                />
              </View>
              <View style={styles.inputContainer}>
                <TextInput
                  style={styles.input}
                  placeholder={t('email')}
                  placeholderTextColor="#888888"
                  value={rep.email}
                  onChangeText={(text) => handleRepresentativeChange(index, 'email', text)}
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              </View>
              <View style={styles.inputContainer}>
                <TextInput
                  style={styles.input}
                  placeholder={t('dateOfDesignation')}
                  placeholderTextColor="#888888"
                  value={rep.dateOfDesignation}
                  onChangeText={(text) => handleRepresentativeChange(index, 'dateOfDesignation', text)}
                  // Ideally, use a date picker component
                />
              </View>
            </View>
          ))}
          <TouchableOpacity style={styles.addButton} onPress={handleAddRepresentative}>
            <Text style={styles.addButtonText}>{t('addRepresentative')}</Text>
          </TouchableOpacity>
        </View>


        {/* Submit Button */}
        <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
          <Text style={styles.buttonText}>{t('completeRegistration')}</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  scrollContent: {
    padding: 20,
    paddingTop: Platform.OS === 'web' ? 40 : 40,
    flexGrow: 1,
  },
  title: {
    fontSize: Platform.OS === 'web' ? 32 : 24,
    color: '#000',
    textAlign: 'center',
    fontWeight: '600',
    marginBottom: 20,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    color: '#000',
    fontWeight: '600',
    marginBottom: 10,
  },
  memberContainer: {
    marginBottom: 15,
    padding: 10,
    backgroundColor: '#228B22',
    borderRadius: 10,
  },
  inputContainer: {
    borderWidth: 1,
    borderColor: '#DAA520',
    borderRadius: 10,
    width: '100%',
    backgroundColor: '#fff',
    marginBottom: 10,
    overflow: 'hidden',
  },
  input: {
    color: '#000',
    height: 50,
    width: '100%',
    fontSize: 14,
    paddingHorizontal: 10,
    
    
  },
  picker: {
    color: '#888888',
    height: 50,
    width: '100%',
    fontSize: 12,
  },
  addButton: {
   backgroundColor: "#FFFFFF",
    borderRadius: 10,
    paddingVertical: 10,
    width: 343,
    alignSelf: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  addButtonText: {
    color: '#228B22',
    fontSize: 16,
    fontWeight: 'bold',
  },
  
  
  submitButton: {
    backgroundColor: '#E6BE00',
    borderRadius: 10,
    paddingVertical: 10,
    width: 343,
    alignItems: 'center',
    marginBottom: 20,
  },
  buttonText: {
    color: '#000',
    fontWeight: 'bold',
    fontSize: 16,
  },

  
});