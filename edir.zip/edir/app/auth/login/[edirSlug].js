import React, { useState, useEffect } from 'react';
import * as SecureStore from 'expo-secure-store';
import { Platform, View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ImageBackground } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { apiCall } from '../../../src/utils/api';
import { saveAuthTokens, clearAuthTokens } from '../../../src/utils/token';
import { Ionicons } from '@expo/vector-icons';
import base64 from 'react-native-base64';
import { decodeJWT } from '../../../src/utils/jwt';

export default function SignIn() {
  const { edirSlug } = useLocalSearchParams();
  const router = useRouter();
  const { t } = useTranslation();
  const [username, setUsername] = useState('');
  const [isApproved, setIsApproved] = useState('pending');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    const loadSavedCredentials = async () => {
      try {
        let savedUsername, savedPassword;
        if (Platform.OS === 'web') {
          savedUsername = await AsyncStorage.getItem('savedUsername');
          savedPassword = await AsyncStorage.getItem('savedPassword');
        } else {
          savedUsername = await SecureStore.getItemAsync('savedUsername');
          savedPassword = await SecureStore.getItemAsync('savedPassword');
        }
        if (savedUsername) setUsername(base64.decode(savedUsername));
        if (savedPassword) setPassword(base64.decode(savedPassword));
      } catch (error) {
        console.error('Failed to load saved credentials:', error);
      }
    };

    loadSavedCredentials();
  }, []);

  const handleLogin = async () => {
    if (!username || !password) {
      Alert.alert(t('fillAllFields'));
      return;
    }

    try {
      await clearAuthTokens();
      console.log('Sending login request with:', { username, password });
      const response = await apiCall(
        `/api/${edirSlug}/auth/login/`,
        'POST',
        { username, password },
        { 'Content-Type': 'application/json' }
      );
      console.log('Login response:', response);

      const accessToken = response.access;
      const refreshToken = response.refresh;

      if (accessToken) {
        await saveAuthTokens({ access: accessToken, refresh: refreshToken });
        await AsyncStorage.setItem('username', response.username);
        await AsyncStorage.setItem('email', response.email);
        await AsyncStorage.setItem('role', response.role);
        await AsyncStorage.setItem('is_edir_head', JSON.stringify(response.is_edir_head));
        await AsyncStorage.setItem('verification_status', response.verification_status);
        await AsyncStorage.setItem('edir', JSON.stringify(response.edir));

        if (Platform.OS === 'web') {
          await AsyncStorage.setItem('savedUsername', base64.encode(username));
          await AsyncStorage.setItem('savedPassword', base64.encode(password));
        } else {
          await SecureStore.setItemAsync('savedUsername', base64.encode(username));
          await SecureStore.setItemAsync('savedPassword', base64.encode(password));
        }
        const decoded = decodeJWT(accessToken);
        console.log('Decoded token:', decoded);

if (decoded?.user_id) {
  await AsyncStorage.setItem('member_id', decoded.user_id.toString());
}


        setIsApproved(response.verification_status);
        router.push(`/member-dashboard/${edirSlug}`);
      } else {
        Alert.alert(t('loginFailed'), t('noTokenReceived'));
      }
    } catch (error) {
      console.error('Login error:', error.message, error.stack);
      Alert.alert(t('loginFailed'), error.message || t('unknownError'));
    }
  };
  const handleForgotPassword = () => {
    router.push(`/auth/forgot-password/${edirSlug}`);
  };

  const handleRegister = () => {
    router.push(`/auth/sign-up/${edirSlug}/register`);
  };

  return (
    <ImageBackground
      source={require('../../../assets/images/as-a-team.jpg')}
      style={styles.background}
      imageStyle={styles.backgroundImage}
    >
      <View style={styles.overlay}>
        <View style={styles.container}>
          <TextInput
            style={styles.input}
            placeholder={t('username')}
            placeholderTextColor="#888888"
            value={username}
            onChangeText={setUsername}
            autoCapitalize="none"
            textContentType="username"
            autoComplete="username"
          />
          <View style={{ width: '100%', position: 'relative' }}>
            <TextInput
              style={styles.input}
              placeholder={t('password')}
              placeholderTextColor="#888888"
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!showPassword}
              autoCapitalize="none"
              textContentType="password"
              autoComplete="password"
            />
            <TouchableOpacity
              style={{ position: 'absolute', right: 10, top: 22 }}
              onPress={() => setShowPassword(prev => !prev)}
            >
              <Ionicons
                name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                size={22}
                color="#888888"
              />
            </TouchableOpacity>
          </View>
          <TouchableOpacity onPress={handleForgotPassword}>
            <Text style={styles.forgotPassword}>{t('forgotPassword')}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
            <Text style={styles.loginButtonText}>{t('login')}</Text>
          </TouchableOpacity>
          <View style={styles.registerContainer}>
            <Text style={styles.registerText}>{t('dontHaveAccount')}</Text>
            <TouchableOpacity onPress={handleRegister}>
              <Text style={styles.registerLink}>{t('register')}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </ImageBackground>
  );
}
const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
  },
  backgroundImage: {
     opacity: 0.6, // Dim the background image
    backgroundColor: '#228B22', // Fallback color that blends with the image
  },
  overlay: {
    flex: 1,
     backgroundColor: 'rgba(102, 184, 48, 0.3)', // Semi-transparent green overlay
    justifyContent: 'center',
    padding: 20,
    paddingBottom:20,
    paddingTop:60
  },
  container: {
    backgroundColor: 'rgba(0, 0, 0, 0.3)', // Darker overlay for content
    borderRadius: 15,
    padding: 15,
    width: '100%',
    maxWidth: 500,
    alignSelf: 'center',
    flexGrow: 1,
      padding: 20,
      paddingTop: Platform.OS === 'web' ? 40 : 200,
  },
  picker: {
    color: '#B2BEB5',
    height: 50,
    width: '100%',
    fontSize: 12,
  },
  input: {
    width: '100%',
    padding: 15,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: '#DAA520',
    borderRadius: 5,
    backgroundColor: 'rgba(245, 245, 245, 0.9)',
    fontSize: 16,
    color: '#000',
  },
  forgotPassword: {
    alignSelf: 'flex-end',
    marginBottom: 20,
    color: '#FFD700',
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  loginButton: {
    backgroundColor: '#E6BE00',
    borderRadius: 10,
    paddingVertical: 15,
    width: '100%',
    alignItems: 'center',
    marginBottom: 20,
  },
  loginButtonText: {
    color: '#000',
    fontSize: 16,
    fontWeight: 'bold',
  },
  registerContainer: {
    flexDirection: 'row',
    marginTop: 20,
    justifyContent: 'center',
  },
  registerText: {
    color: '#fff',
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  registerLink: {
    color: '#FFD700',
    marginLeft: 5,
    textDecorationLine: 'underline',
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
});