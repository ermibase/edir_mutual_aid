import { Stack } from "expo-router";
       import { UserProvider } from "../src/contexts/UserContext";
       import { RegistrationProvider } from "../src/contexts/RegistrationContext";
       import "../src/i18n";
       import GoogleTranslateWidget from "../components/GoogleTranslateWidget";
       import LanguageSelector from '../components/LanguageSelector';
       import React, { useEffect, useRef, useState } from 'react';
       import { useTranslation } from 'react-i18next';
       import { registerForPushNotificationsAsync, setupNotificationListeners } from '../src/utils/notifications';
       import { SafeAreaProvider , SafeAreaView} from 'react-native-safe-area-context';

       export default function RootLayout() {
        const { i18n } = useTranslation();
         const [language, setLanguage] = useState(i18n.language);
         const [languageModalVisible, setLanguageModalVisible] = useState(false);
         

        console.log("Rendering RootLayout");
        const handleLanguageChange = (lang) => {
    setLanguage(lang);
    i18n.changeLanguage(lang);
  };
  //  useEffect(() => {
  //   registerForPushNotificationsAsync();
  // }, []);

  // useEffect(() => {
  //   setupNotificationListeners();
  //   registerForPushNotificationsAsync().then(token => {
  //     if (token) {
  //       // Send token to your backend
  //     }
  //   });
  // }, []);
         return (
              <SafeAreaProvider>
               <SafeAreaView style={{ flex: 1 }} edges={['right', 'bottom', 'left']}>
           <UserProvider>
             <RegistrationProvider>
               <Stack>
                 <Stack.Screen name="index" options={{ headerShown: false }} />
                 <Stack.Screen name="auth" options={{ headerShown: false }} />
                 <Stack.Screen name="member-dashboard/[edirSlug]" options={{ headerShown: false }} />
               </Stack>
                <LanguageSelector handleLanguageChange={handleLanguageChange} />
               <GoogleTranslateWidget />
             </RegistrationProvider>
           </UserProvider>
           </SafeAreaView>
               </SafeAreaProvider>

         );
       }