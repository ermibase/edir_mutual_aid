import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  Platform,
  Alert,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { apiCall } from '../../../src/utils/api';
import { useLocalSearchParams, useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function ProfileScreen() {
  const [image, setImage] = useState(null);
  const [profile, setProfile] = useState({});
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [memberId, setMemberId] = useState(null);
  const { edirSlug } = useLocalSearchParams();
  const router = useRouter();

  useEffect(() => {
    const loadMemberId = async () => {
      const storedId = await AsyncStorage.getItem('member_id');
      if (storedId) {
        setMemberId(storedId);
      } else {
        Alert.alert('Error', 'Member ID not found');
        router.replace('/auth/sign-in');
      }
    };
    loadMemberId();
  }, []);

  useEffect(() => {
    if (memberId && edirSlug) fetchProfile();
  }, [memberId, edirSlug]);

  const fetchProfile = async () => {
    try {
      const data = await apiCall(`/api/${edirSlug}/members/${memberId}/`);
      setProfile(data);
    } catch (err) {
      console.error(err);
      Alert.alert('Error', 'Failed to fetch profile');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      const updatedData = { ...profile };

      // Remove spouse/family if not 'family' type (redundant but safe)
      if (profile.registration_type !== 'family') {
        delete updatedData.spouse;
        delete updatedData.family_members;
      }

      await apiCall(`/api/${edirSlug}/members/${memberId}/`, 'PUT', updatedData);
      Alert.alert('Success', 'Profile updated');
      setIsEditing(false);
    } catch (err) {
      console.error(err);
      Alert.alert('Error', 'Failed to update profile');
    }
  };

  const handleAddFamilyMember = () => {
    const updatedMembers = [...(profile.family_members || []), { full_name: '', gender: '', date_of_birth: '', relationship: '' }];
    setProfile({ ...profile, family_members: updatedMembers });
  };

  const renderInput = (label, key, placeholder = '') => (
    <TextInput
      style={styles.input}
      value={profile[key] || ''}
      onChangeText={(text) => setProfile({ ...profile, [key]: text })}
      placeholder={placeholder || label}
    />
  );

   const pickImage = async () => {
    if (Platform.OS === 'web') {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.onchange = (event) => {
        const file = event.target.files[0];
        if (file) {
          const imageUrl = URL.createObjectURL(file);
          setImage(imageUrl);
        }
      };
      input.click();
    } else {
      const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permissionResult.granted) {
        Alert.alert('Permission Denied', 'You need to allow access to your photos.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 1,
      });
      

      if (!result.canceled) {
        setImage(result.assets[0].uri);
      }
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator color="white" size="large" />
      </View>
    );
  }
 const handleLog = ()=>{
    router.push(`/auth/login/${edirSlug}`);
  }
  return (
    <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
      <Text style={styles.title}>My Profile</Text>

      <TouchableOpacity onPress={pickImage}>
        <View style={styles.imageContainer}>
          {image ? (
            <Image source={{ uri: image }} style={styles.image} />
          ) : (
            <Ionicons name="person-circle-outline" size={100} color="#B2BEB5" />
          )}
        </View>
      </TouchableOpacity>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Basic Info</Text>
          <TouchableOpacity onPress={() => setIsEditing(!isEditing)}>
            <Ionicons name="create-outline" size={20} color="#000" />
          </TouchableOpacity>
        </View>

        {isEditing ? (
          <>
            {renderInput('Full Name', 'full_name')}
            {renderInput('Email', 'email')}
            {renderInput('Phone', 'phone_number')}
            {renderInput('City', 'city')}
            {renderInput('Address', 'address')}
            {renderInput('State', 'state')}
            {renderInput('Zip Code', 'zip_code')}
            {renderInput('Alt Phone', 'home_or_alternate_phone')}
          </>
        ) : (
          <>
            <Text style={styles.fieldText}>👤 Name: {profile.full_name}</Text>
            <Text style={styles.fieldText}>📧 Email: {profile.email}</Text>
            <Text style={styles.fieldText}>📞 Phone: {profile.phone_number}</Text>
            <Text style={styles.fieldText}>🏙️ City: {profile.city}</Text>
            <Text style={styles.fieldText}>🏠 Address: {profile.address}</Text>
            <Text style={styles.fieldText}>🧾 Type: {profile.registration_type}</Text>
            <Text style={styles.fieldText}>📞 Alternative phone: {profile.home_or_alternate_phone}</Text>
            <Text style={styles.fieldText}>🏛  Zip Code : {profile.zip_code}</Text>
            <Text style={styles.fieldText}>🏤 State: {profile.state}</Text>
          </>
        )}

        {/* Conditionally show spouse/family section only for 'family' */}
        {isEditing && profile.registration_type === 'family' && (
          <>
            <Text style={styles.sectionTitle}>Spouse Info</Text>
            {['full_name', 'email', 'phone_number'].map((key) => (
              <TextInput
                key={key}
                style={styles.input}
                placeholder={key.replace('_', ' ')}
                value={profile.spouse?.[key] || ''}
                onChangeText={(text) =>
                  setProfile({ ...profile, spouse: { ...profile.spouse, [key]: text } })
                }
              />
            ))}

            <Text style={styles.sectionTitle}>Family Members</Text>
            {profile.family_members?.map((member, index) => (
              <View key={index} style={{ marginBottom: 10 }}>
                <TextInput
                  style={styles.input}
                  placeholder="Full Name"
                  value={member.full_name}
                  onChangeText={(text) => {
                    const updated = [...profile.family_members];
                    updated[index].full_name = text;
                    setProfile({ ...profile, family_members: updated });
                  }}
                />
                <TextInput
                  style={styles.input}
                  placeholder="Gender"
                  value={member.gender}
                  onChangeText={(text) => {
                    const updated = [...profile.family_members];
                    updated[index].gender = text;
                    setProfile({ ...profile, family_members: updated });
                  }}
                />
                <TextInput
                  style={styles.input}
                  placeholder="DOB"
                  value={member.date_of_birth}
                  onChangeText={(text) => {
                    const updated = [...profile.family_members];
                    updated[index].date_of_birth = text;
                    setProfile({ ...profile, family_members: updated });
                  }}
                />
                <TextInput
                  style={styles.input}
                  placeholder="Relationship"
                  value={member.relationship}
                  onChangeText={(text) => {
                    const updated = [...profile.family_members];
                    updated[index].relationship = text;
                    setProfile({ ...profile, family_members: updated });
                  }}
                />
              </View>
            ))}
            <TouchableOpacity onPress={handleAddFamilyMember} style={styles.saveButton}>
              <Text style={styles.buttonText}>Add Family Member</Text>
            </TouchableOpacity>
          </>
        )}

        {isEditing && (
          <TouchableOpacity onPress={handleSave} style={styles.saveButton}>
            <Text style={styles.buttonText}>Save Profile</Text>
          </TouchableOpacity>
        )}
      </View>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Security</Text>
        <TouchableOpacity style={styles.changePasswordButton}>
          <Text style={styles.buttonText}>Change Password</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={{ marginTop: 30, marginBottom: 50 }}  onPress={handleLog}>
        <Text style={{ color: 'black', fontWeight: 'bold', textAlign: 'center',fontSize:16 }}>
          Log Out
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  scrollView: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  scrollContent: {
    paddingTop: 60,
    paddingBottom: 100,
    paddingHorizontal: 20,
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: '#000',
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    color: 'black',
    fontSize: 20,
    textAlign: 'center',
    marginBottom: 20,
    fontWeight: 'bold',
  },
  imageContainer: {
    alignSelf: 'center',
    borderRadius: 75,
    overflow: 'hidden',
    width: 150,
    height: 150,
    marginBottom: 10,
    backgroundColor: '#23A032',
    justifyContent: 'center',
    alignItems: 'center',
    borderColor:'black'
  },
  image: {
    width: 150,
    height: 150,
    borderRadius: 60,
  },
  section: {
    marginTop: 25,
    
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
    
  },
  sectionTitle: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
  },
  input: {
    backgroundColor: '#fff',
    borderColor: '#B2BEB5',
    borderWidth: 1,
    borderRadius: 5,
    color: '#000',
    paddingHorizontal: 10,
    height: 50,
    marginBottom: 10,
    fontSize: 14,
    
    
  },
  saveButton: {
    backgroundColor: '#23A032',
    borderRadius: 10,
    paddingVertical: 10,
    marginTop: 5,
    alignItems: 'center',
  },
  changePasswordButton: {
    backgroundColor: '#23A032',
    borderRadius: 10,
    paddingVertical: 10,
    marginTop: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 14,
  },
  fieldText: {
  fontSize: 14,
  lineHeight:25
},
  
});
