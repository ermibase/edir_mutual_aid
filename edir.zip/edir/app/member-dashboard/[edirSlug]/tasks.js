import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, ActivityIndicator, Platform, SafeAreaView } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { apiCall } from '../../../src/utils/api';
import { getAccessToken } from '../../../src/utils/token';
import AsyncStorage from '@react-native-async-storage/async-storage';

const TasksScreen = () => {
  const { edirSlug } = useLocalSearchParams();
  const [tasks, setTasks] = useState([]);
  const [activeTab, setActiveTab] = useState('All');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [modalMessage, setModalMessage] = useState('');

  const showMessage = (message) => {
    console.log(`[${Platform.OS}] Showing message:`, message);
    if (Platform.OS === 'web') {
      alert(message);
    } else {
      setModalMessage(message);
      setShowMessageModal(true);
    }
  };

  useEffect(() => {
    const fetchTasks = async () => {
      setLoading(true);
      try {
        const token = await getAccessToken();
        const memberId = await AsyncStorage.getItem('member_id');
        console.log(`[${Platform.OS}] Access Token:`, token ? token.substring(0, 10) + '...' : 'null');
        console.log(`[${Platform.OS}] Member ID:`, memberId);
        if (!token) {
          showMessage('No access token found. Please log in again.');
          setLoading(false);
          return;
        }
        const data = await apiCall(`/api/${edirSlug}/tasks/my-assigned/?member_id=${memberId}`, 'GET', null, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        console.log(`[${Platform.OS}] Fetched tasks:`, data);
        setTasks(data);
        setLoading(false);
      } catch (err) {
        console.error(`[${Platform.OS}] Error fetching tasks:`, err.message);
        setError('Failed to load tasks');
        setLoading(false);
      }
    };
    fetchTasks();
  }, [edirSlug]);

  const handleCompleteTask = async (taskId) => {
    try {
      const token = await getAccessToken();
      console.log(`[${Platform.OS}] Access Token:`, token ? token.substring(0, 10) + '...' : 'null');
      if (!token) {
        showMessage('No access token found. Please log in again.');
        return;
      }
      const response = await apiCall(`/api/${edirSlug}/tasks/my-assigned/${taskId}/complete/`, 'POST', {}, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      console.log(`[${Platform.OS}] Task completion response:`, response);
      setTasks(tasks.map(task =>
        task.id === taskId ? { ...task, status: 'completed', completed_at: new Date().toISOString() } : task
      ));
      showMessage('Task marked as complete');
    } catch (err) {
      console.error(`[${Platform.OS}] Error completing task:`, err.message);
      showMessage('Failed to mark task as complete: ' + err.message);
    }
  };

  const filteredTasks = tasks.filter(task => {
    if (activeTab === 'All') return true;
    if (activeTab === 'Today') {
      const today = new Date();
      const dueDate = new Date(task.due_date);
      return dueDate.toDateString() === today.toDateString();
    }
    if (activeTab === 'Completed') return task.status === 'completed';
    return true;
  });

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.header}>My Assigned Tasks</Text>

        <View style={styles.tabContainer}>
          {['All', 'Today', 'Completed'].map(tab => (
            <TouchableOpacity
              key={tab}
              style={[styles.tabButton, activeTab === tab && styles.activeTab]}
              onPress={() => setActiveTab(tab)}
            >
              <Text style={[styles.tabText, activeTab === tab && styles.activeTabText]}>
                {tab}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {loading ? (
          <ActivityIndicator size="large" color="#23A032" />
        ) : error ? (
          <Text style={styles.errorText}>{error}</Text>
        ) : filteredTasks.length === 0 ? (
          <Text style={styles.noTasksText}>No tasks assigned to you</Text>
        ) : (
          <View style={styles.taskContainer}>
            {filteredTasks.map(task => (
              <View key={task.id} style={styles.taskItem}>
                <View style={styles.taskDetails}>
                  <Text style={styles.taskTitle}>{task.title}</Text>
                  <Text style={styles.taskDescription}>{task.description || 'No description'}</Text>
                  <Text style={styles.taskTime}>
                    {task.shift_display || new Date(task.due_date).toLocaleString()}
                  </Text>
                  <Text style={styles.taskGroup}>Group: {task.task_group_name}</Text>
                  <Text style={styles.taskPriority}>Priority: {task.priority}</Text>
                  <Text style={styles.taskAssignedBy}>Assigned by: {task.assigned_by_name}</Text>
                  <TouchableOpacity
                    style={[styles.completeButton, task.status === 'completed' && styles.completeButtonDisabled]}
                    onPress={() => handleCompleteTask(task.id)}
                    disabled={task.status === 'completed'}
                  >
                    <Text style={styles.completeButtonText}>
                      {task.status === 'completed' ? 'Completed' : 'Mark as Complete'}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            ))}
          </View>
        )}

        {showMessageModal && (
          <View style={styles.modalOverlay}>
            <View style={styles.modalBox}>
              <Text style={styles.modalTitle}>Task Status</Text>
              <Text style={styles.modalSubtitle}>{modalMessage}</Text>
              <TouchableOpacity
                style={[styles.modalButton, { backgroundColor: '#23A032' }]}
                onPress={() => setShowMessageModal(false)}
              >
                <Text style={styles.modalButtonText}>OK</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    paddingTop: 40,
  },
  content: {
    padding: 20,
    paddingBottom: 100,
  },
  header: {
    color: 'black',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    marginTop:-20,
  },
  tabContainer: {
    flexDirection: 'row',
    marginBottom: 20,
    backgroundColor: '#a6dbbc',
    borderRadius: 10,
    overflow: 'hidden',
  },
  tabButton: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  activeTab: {
    backgroundColor: '#23A032',
  },
  tabText: {
    color: '#000',
    fontSize: 14,
  },
  activeTabText: {
    color: '#000',
    fontWeight: 'bold',
  },
  taskContainer: {
    borderRadius: 0,
    overflow: 'hidden',
  },
  taskItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#fff',
    borderRadius: 10,
  },
  taskDetails: {
    flex: 1,
  },
  taskTitle: {
    color: 'black',
    fontSize: 14,
    marginBottom: 4,
  },
  taskDescription: {
    color: '#333333',
    fontSize: 12,
    marginBottom: 4,
  },
  taskTime: {
    color: '#333333',
    fontSize: 12,
    marginBottom: 4,
  },
  taskGroup: {
    color: '#333',
    fontSize: 12,
    marginBottom: 4,
  },
  taskPriority: {
    color: '#333',
    fontSize: 12,
    marginBottom: 4,
  },
  taskAssignedBy: {
    color: '#333',
    fontSize: 12,
    marginBottom: 8,
  },
  completeButton: {
    backgroundColor: '#23A032',
    borderRadius: 5,
    paddingVertical: 10,
    paddingHorizontal: 12,
    alignItems: 'center',
  },
  completeButtonDisabled: {
    backgroundColor: '#666',
  },
  completeButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: 'bold',
  },
  errorText: {
    color: '#FF6B6B',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 20,
  },
  noTasksText: {
    color: '#B2BEB5',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 20,
  },
  modalOverlay: {
    position: 'absolute',
    top: 60,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  modalBox: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 12,
    width: '80%',
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'black',
    marginBottom: 10,
  },
  modalSubtitle: {
    fontSize: 14,
    color: '#333',
    marginBottom: 20,
    textAlign: 'center',
  },
  modalButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
    marginBottom: 10,
    width: '100%',
    alignItems: 'center',
  },
  modalButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default TasksScreen;