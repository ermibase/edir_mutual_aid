import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet, ActivityIndicator, TouchableOpacity } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { useTranslation } from 'react-i18next';
import { apiCall } from '../../../src/utils/api';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function RemindersPage() {
  const { edirSlug } = useLocalSearchParams();
  const { t } = useTranslation();
  const [reminders, setReminders] = useState([]);
  const [payments, setPayments] = useState([]);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [memberId, setMemberId] = useState(null);

  useEffect(() => {
    const fetchMemberId = async () => {
      try {
        const id = await AsyncStorage.getItem('member_id');
        setMemberId(id);
      } catch (err) {
        console.error('Failed to fetch member ID:', err);
      }
    };
    fetchMemberId();
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      if (!memberId) return;
      setLoading(true);
      try {
        // Fetch reminders for the user
        const remindersData = await apiCall(`/api/${edirSlug}/reminders/${memberId}/`);
        setReminders(remindersData);

        // Fetch pending payments
        const paymentsData = await apiCall(`/api/${edirSlug}/payments/`);
        const pendingPayments = paymentsData.filter(payment => 
          payment.member === parseInt(memberId) && payment.status === 'pending'
        );
        setPayments(pendingPayments);

        // Fetch all events
        const eventsData = await apiCall(`/api/${edirSlug}/events/`);
        setEvents(eventsData);
      } catch (err) {
        setError(err.message || t('fetchError'));
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [edirSlug, memberId, t]);

  const renderReminderItem = ({ item }) => (
    <View style={styles.itemContainer}>
      <View style={styles.itemHeader}>
        <Text style={styles.itemTitle}>{item.subject}</Text>
        <Ionicons name={item.status === 'sent' ? 'checkmark-circle' : 'time-outline'} size={20} color={item.status === 'sent' ? '#4CAF50' : '#888'} />
      </View>
      <Text style={styles.itemText}>{item.message}</Text>
      <Text style={styles.itemSubText}>
        {t('scheduled')}: {new Date(item.scheduled_time).toLocaleString()}
      </Text>
      <Text style={styles.itemSubText}>{t('channel')}: {item.channel_display}</Text>
    </View>
  );

  const renderPaymentItem = ({ item }) => (
    <View style={styles.itemContainer}>
      <View style={styles.itemHeader}>
        <Text style={styles.itemTitle}>{item.payment_type_display}</Text>
        <Ionicons name="cash-outline" size={20} color="#888" />
      </View>
      <Text style={styles.itemText}>{t('amount')}: {item.amount}</Text>
      <Text style={styles.itemSubText}>
        {t('dueDate')}: {item.payment_date ? new Date(item.payment_date).toLocaleDateString() : t('notSet')}
      </Text>
    </View>
  );

  const renderEventItem = ({ item }) => (
    <View style={styles.itemContainer}>
      <View style={styles.itemHeader}>
        <Text style={styles.itemTitle}>{item.title}</Text>
        <Ionicons name={item.is_active ? 'calendar' : 'calendar-outline'} size={20} color={item.is_active ? '#4CAF50' : '#888'} />
      </View>
      <Text style={styles.itemText}>{item.description}</Text>
      <Text style={styles.itemSubText}>
        {t('startDate')}: {new Date(item.start_date).toLocaleString()}
      </Text>
      <Text style={styles.itemSubText}>{t('location')}: {item.location}</Text>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#E6BE00" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>{error}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.sectionTitle}>{t('reminders')}</Text>
      <FlatList
        data={reminders}
        renderItem={renderReminderItem}
        keyExtractor={item => item.id.toString()}
        ListEmptyComponent={<Text style={styles.emptyText}>{t('noReminders')}</Text>}
        style={styles.list}
      />

      <Text style={styles.sectionTitle}>{t('pendingPayments')}</Text>
      <FlatList
        data={payments}
        renderItem={renderPaymentItem}
        keyExtractor={item => item.id.toString()}
        ListEmptyComponent={<Text style={styles.emptyText}>{t('noPayments')}</Text>}
        style={styles.list}
      />

      <Text style={styles.sectionTitle}>{t('events')}</Text>
      <FlatList
        data={events}
        renderItem={renderEventItem}
        keyExtractor={item => item.id.toString()}
        ListEmptyComponent={<Text style={styles.emptyText}>{t('noEvents')}</Text>}
        style={styles.list}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    padding: 20,
  },
  errorText: {
    color: '#D32F2F',
    fontSize: 16,
    textAlign: 'center',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginVertical: 10,
  },
  list: {
    marginBottom: 20,
  },
  itemContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  itemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  itemTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  itemText: {
    fontSize: 14,
    color: '#555',
    marginBottom: 5,
  },
  itemSubText: {
    fontSize: 12,
    color: '#888',
  },
  emptyText: {
    fontSize: 14,
    color: '#888',
    textAlign: 'center',
    padding: 20,
  },
});