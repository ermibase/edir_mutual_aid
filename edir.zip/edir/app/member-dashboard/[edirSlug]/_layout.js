import { Slot } from 'expo-router';
import { Text,View, StyleSheet } from 'react-native';
import { useLocalSearchParams, useSegments } from 'expo-router';
import { useEffect } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import CustomHeaderWithMenu from '../../../components/CustomHeaderWithMenu';
import BottomTabBar from '../../../components/BottomTabBar'; // You'll create this in step 2

export default function Layout() {
  const { top } = useSafeAreaInsets();
  const { edirSlug } = useLocalSearchParams();
  const prefix = edirSlug.slice(0, -4);
const suffix = edirSlug.slice(-4);   

  return (
    <View style={[styles.container,{ paddingTop: top }]}>
      {/* Custom header with menu */}

  <CustomHeaderWithMenu
  title={
    <Text style={styles.titleText}>
      <Text style={{ color: '#fff' }}>{prefix}</Text>
      <Text style={{ color: '#38bdf8' }}>{suffix}</Text>
    </Text>
  }
/>

 {/* All child screens go here */}
      <View style={styles.content}>
        <Slot />
      </View>

      {/* Custom bottom tab bar (not using Tabs.Screen directly) */}
      <BottomTabBar edirSlug={edirSlug} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  content: {
    flex: 1,

  },
   titleText: {
    fontSize: 20,
    fontWeight: 'bold',
  },
});