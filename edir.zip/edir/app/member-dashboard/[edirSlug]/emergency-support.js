import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TextInput, TouchableOpacity, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { useLocalSearchParams } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { apiCall } from '../../../src/utils/api';
import Checkbox from 'expo-checkbox';
import { Ionicons } from '@expo/vector-icons';

const SupportScreen = () => {
  const { edir_slug } = useLocalSearchParams();
  const [memberId, setMemberId] = useState(null);
  const [effectiveEdirSlug, setEffectiveEdirSlug] = useState(null);
  const [emergencyType, setEmergencyType] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [requestedAmount, setRequestedAmount] = useState('');
  const [emergencyId, setEmergencyId] = useState('');
  const [emergencies, setEmergencies] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoadingRequests, setIsLoadingRequests] = useState(false);
  const [error, setError] = useState(null);
  const [activeCard, setActiveCard] = useState(null);
  const [updateFields, setUpdateFields] = useState({
    emergencyType: false,
    title: false,
    description: false,
    requestedAmount: false,
  });

  // Fetch memberId and edir_slug from AsyncStorage on component mount
  useEffect(() => {
    const initializeData = async () => {
      try {
        const id = await AsyncStorage.getItem('member_id');
        if (id) {
          setMemberId(id);
        } else {
          setError('Member ID not found. Please log in again.');
        }

        let slug = edir_slug;
        if (!slug) {
          const edir = await AsyncStorage.getItem('edir');
          if (edir) {
            try {
              slug = JSON.parse(edir).slug || edir;
            } catch (e) {
              console.error('Failed to parse edir from AsyncStorage:', e);
            }
          }
        }
        if (slug) {
          setEffectiveEdirSlug(slug);
        } else {
          setError('Edir slug not found. Please access this page through your dashboard.');
        }
      } catch (err) {
        setError('Failed to retrieve required data. Please log in again.');
      }
    };
    initializeData();
  }, [edir_slug]);

  // Handle form submission to create a new emergency request
  const handleSubmit = async () => {
    if (!memberId || !effectiveEdirSlug) {
      setError('Required data missing. Please log in again.');
      return;
    }
    if (!emergencyType || !title || !description) {
      setError('Please fill all required fields: Emergency Type, Title, Description');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const data = {
        member: memberId,
        emergency_type: emergencyType,
        title: title,
        description: description,
        requested_amount: requestedAmount || null,
      };
      const response = await apiCall(`/api/${effectiveEdirSlug}/emergencies/`, 'POST', data);
      Alert.alert(
        'Request Submitted',
        `Your emergency request "${title}" has been successfully submitted! Request ID: ${response.id}`,
        [{ text: 'OK', onPress: () => console.log('OK Pressed') }]
      );
      // Reset form
      setEmergencyType('');
      setTitle('');
      setDescription('');
      setRequestedAmount('');
    } catch (err) {
      setError(err.message || 'Failed to submit request. Please check your input values.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Fetch user's emergency requests
  const handleListRequests = async () => {
    if (!memberId || !effectiveEdirSlug) {
      setError('Required data missing. Please log in again.');
      return;
    }

    setIsLoadingRequests(true);
    setError(null);
    try {
      const data = await apiCall(`/api/${effectiveEdirSlug}/emergencies/?member=${memberId}`, 'GET');
      setEmergencies(data);
      // Alert.alert(
      //   'Requests Loaded',
      //   data.length > 0 ? 'Here are your emergency requests.' : 'You have no emergency requests yet.',
      //   [{ text: 'OK' }]
      // );
    } catch (err) {
      setError(err.message || 'Failed to fetch your emergency requests.');
    } finally {
      setIsLoadingRequests(false);
    }
  };

  // Handle GET request to view emergency details
  const handleGetEmergency = async (id) => {
    if (!id) {
      setError('Please select an emergency request to view details.');
      return;
    }
    if (!effectiveEdirSlug) {
      setError('Edir slug not available. Please access this page through your dashboard.');
      return;
    }

    setError(null);
    try {
      const data = await apiCall(`/api/${effectiveEdirSlug}/emergencies/${id}/`, 'GET');
      console.log('GET Emergency Response:', data);
      setActiveCard({ type: 'detail', data });
    } catch (err) {
      setError(err.message || 'Failed to fetch emergency details.');
    }
  };

  // Handle PUT request to update an emergency
  const handleUpdateEmergency = async (id) => {
    if (!id) {
      setError('Please select an emergency request to update.');
      return;
    }
    if (!effectiveEdirSlug) {
      setError('Edir slug not available. Please access this page through your dashboard.');
      return;
    }

    setError(null);
    try {
      const data = await apiCall(`/api/${effectiveEdirSlug}/emergencies/${id}/`, 'GET');
      setActiveCard({ type: 'update', data: { ...data, emergencyType: data.emergency_type } });
    } catch (err) {
      setError(err.message || 'Failed to fetch emergency for update.');
    }
  };

  // Handle PATCH request to partially update an emergency
  const handlePatchEmergency = async (id) => {
    if (!id) {
      setError('Please select an emergency request to update.');
      return;
    }
    if (!effectiveEdirSlug) {
      setError('Edir slug not available. Please access this page through your dashboard.');
      return;
    }

    setError(null);
    try {
      const data = await apiCall(`/api/${effectiveEdirSlug}/emergencies/${id}/`, 'GET');
      setActiveCard({ type: 'patch', data: { ...data, emergencyType: data.emergency_type } });
    } catch (err) {
      setError(err.message || 'Failed to fetch emergency for partial update.');
    }
  };

  // Handle DELETE request to remove an emergency
  const handleDeleteEmergency = async (id) => {
    if (!id) {
      setError('Please select an emergency request to delete.');
      return;
    }
    if (!effectiveEdirSlug) {
      setError('Edir slug not available. Please access this page through your dashboard.');
      return;
    }

    setError(null);
    try {
      await apiCall(`/api/${effectiveEdirSlug}/emergencies/${id}/`, 'DELETE');
      Alert.alert(
        'Request Deleted',
        `Emergency request ID ${id} has been successfully deleted!`,
        [{ text: 'OK', onPress: () => console.log('OK Pressed') }]
      );
      setEmergencies(emergencies.filter((e) => e.id !== parseInt(id)));
      setEmergencyId('');
      setActiveCard(null);
    } catch (err) {
      if (err.status === 204 || !err.response) {
        Alert.alert(
          'Request Deleted',
          `Emergency request ID ${id} has been successfully deleted!`,
          [{ text: 'OK', onPress: () => console.log('OK Pressed') }]
        );
        setEmergencies(emergencies.filter((e) => e.id !== parseInt(id)));
        setEmergencyId('');
        setActiveCard(null);
      } else {
        setError(err.message || 'Failed to delete emergency request.');
      }
    }
  };

  // Handle update form submission
  const handleUpdateSubmit = async (data) => {
    if (!data.emergencyType || !data.title || !data.description) {
      setError('Please fill all required fields: Emergency Type, Title, Description');
      return;
    }

    try {
      const payload = {
        member: memberId,
        emergency_type: data.emergencyType,
        title: data.title,
        description: data.description,
        requested_amount: data.requestedAmount || null,
      };
      await apiCall(`/api/${effectiveEdirSlug}/emergencies/${data.id}/`, 'PUT', payload);
      Alert.alert(
        'Request Updated',
        `Emergency request ID ${data.id} has been successfully updated!`,
        [{ text: 'OK', onPress: () => setActiveCard(null) }]
      );
      handleListRequests();
    } catch (err) {
      setError(err.message || 'Failed to update emergency request.');
    }
  };

  // Handle patch form submission
  const handlePatchSubmit = async (data, fields) => {
    if (!Object.values(fields).some((checked) => checked)) {
      setError('Please select at least one field to update.');
      return;
    }

    try {
      const payload = {};
      if (fields.emergencyType && data.emergencyType) payload.emergency_type = data.emergencyType;
      if (fields.title && data.title) payload.title = data.title;
      if (fields.description && data.description) payload.description = data.description;
      if (fields.requestedAmount) payload.requested_amount = data.requestedAmount || null;

      if (Object.keys(payload).length === 0) {
        setError('No valid fields selected for update.');
        return;
      }

      await apiCall(`/api/${effectiveEdirSlug}/emergencies/${data.id}/`, 'PATCH', payload);
      Alert.alert(
        'Request Partially Updated',
        `Emergency request ID ${data.id} has been successfully updated!`,
        [{ text: 'OK', onPress: () => setActiveCard(null) }]
      );
      handleListRequests();
    } catch (err) {
      setError(err.message || 'Failed to partially update emergency request.');
    }
  };

  // Handle hide requests
  const handleHideRequests = () => {
    setEmergencies([]);
    setEmergencyId('');
    setActiveCard(null);
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.header}>Support</Text>
        {error && <Text style={styles.errorText}>{error}</Text>}

        {/* Emergency Type Picker */}
        <View style={styles.inputContainer}>
          <Picker
            selectedValue={emergencyType}
            onValueChange={(itemValue) => setEmergencyType(itemValue)}
            style={styles.input}
          >
            <Picker.Item label="Select issue type" value="" />
            <Picker.Item label="Medical" value="medical" />
            <Picker.Item label="Financial" value="financial" />
            <Picker.Item label=" Death" value="death" />
            <Picker.Item label="Accident" value="accident" />
            <Picker.Item label="Other" value="other" />
          </Picker>
        </View>

        {/* Title Input */}
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Title *"
            placeholderTextColor="#888"
            value={title}
            onChangeText={setTitle}
          />
        </View>

        {/* Description Input */}
        <View style={styles.inputContainer}>
          <TextInput
            style={[styles.input, { height: 100, textAlignVertical: 'top' }]}
            placeholder="Description *"
            placeholderTextColor="#888"
            multiline
            value={description}
            onChangeText={setDescription}
          />
        </View>

        {/* Requested Amount Input */}
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Requested Amount (optional)"
            placeholderTextColor="#888"
            keyboardType="numeric"
            value={requestedAmount}
            onChangeText={setRequestedAmount}
          />
        </View>

        {/* Submit Button */}
        <TouchableOpacity
          style={styles.submitButton}
          onPress={handleSubmit}
          disabled={isSubmitting}
        >
          <Text style={styles.buttonText}>
            {isSubmitting ? 'Submitting...' : 'Submit Request'}
          </Text>
        </TouchableOpacity>

        {/* List My Requests Button */}
        <TouchableOpacity
          style={styles.actionButton}
          onPress={handleListRequests}
          disabled={isLoadingRequests}
        >
          <View style={styles.buttonContent}>
            {isLoadingRequests && <ActivityIndicator size="small" color="#FFFFFF" style={styles.spinner} />}
            <Text style={styles.buttonText}>
              {isLoadingRequests ? 'Loading...' : 'List My Requests'}
            </Text>
          </View>
        </TouchableOpacity>

        {/* Emergency Requests List */}
        {emergencies.length > 0 && (
          <View style={styles.requestsContainer}>
            <Text style={styles.subHeader}>Your Emergency Requests</Text>
            {emergencies.map((emergency) => (
              <View key={emergency.id} style={[styles.requestCard, emergencyId === emergency.id.toString() && styles.selectedCard]}>
                <TouchableOpacity onPress={() => setEmergencyId(emergency.id.toString())}>
                  <Text style={styles.requestTitle}>{emergency.title} (ID: {emergency.id})</Text>
                  <Text style={styles.requestDetail}>Type: {emergency.emergency_type}</Text>
                  <Text style={styles.requestDetail}>Status: {emergency.status || 'N/A'}</Text>
                </TouchableOpacity>
                <View style={styles.iconContainer}>
                  <TouchableOpacity onPress={() => handleGetEmergency(emergency.id.toString())}>
                    <Ionicons name="eye" size={24} color="#B2BEB5" style={styles.icon} />
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => handleUpdateEmergency(emergency.id.toString())}>
                    <Ionicons name="pencil" size={24} color="#B2BEB5" style={styles.icon} />
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => handlePatchEmergency(emergency.id.toString())}>
                    <Ionicons name="create" size={24} color="#B2BEB5" style={styles.icon} />
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => handleDeleteEmergency(emergency.id.toString())}>
                    <Ionicons name="trash" size={24} color="#B2BEB5" style={styles.icon} />
                  </TouchableOpacity>
                </View>
              </View>
            ))}
            <TouchableOpacity
              style={styles.hideButton}
              onPress={handleHideRequests}
            >
              <Text style={styles.hideButtonText}>Hide</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Active Card (Detail, Update, or Patch) */}
        {activeCard && (
          <View style={[styles.requestCard, styles.activeCard]}>
            {activeCard.type === 'detail' && (
              <>
                <Text style={styles.requestTitle}>Emergency Details (ID: {activeCard.data.id})</Text>
                <Text style={styles.requestDetail}>Title: {activeCard.data.title || 'N/A'}</Text>
                <Text style={styles.requestDetail}>Type: {activeCard.data.emergency_type || 'N/A'}</Text>
                <Text style={styles.requestDetail}>Description: {activeCard.data.description || 'N/A'}</Text>
                <Text style={styles.requestDetail}>Requested Amount: {activeCard.data.requested_amount || 'N/A'}</Text>
                <Text style={styles.requestDetail}>Status: {activeCard.data.status || 'N/A'}</Text>
                <Text style={styles.requestDetail}>Created: {activeCard.data.created_at || 'N/A'}</Text>
                <TouchableOpacity
                  style={styles.hideButton}
                  onPress={() => setActiveCard(null)}
                >
                  <Text style={styles.hideButtonText}>Hide</Text>
                </TouchableOpacity>
              </>
            )}

            {activeCard.type === 'update' && (
              <>
                <Text style={styles.requestTitle}>Update Emergency (ID: {activeCard.data.id})</Text>
                <View style={styles.inputContainer}>
                  <Picker
                    selectedValue={activeCard.data.emergencyType}
                    onValueChange={(value) => setActiveCard({ ...activeCard, data: { ...activeCard.data, emergencyType: value } })}
                    style={styles.input}
                  >
                    <Picker.Item label="Select issue type" value="" />
                    <Picker.Item label="Medical" value="medical" />
                    <Picker.Item label="Financial" value="financial" />
                    <Picker.Item label="Death" value="death" />
                    <Picker.Item label="Accident" value="accident" />
                    <Picker.Item label="Other" value="other" />
                  </Picker>
                </View>
                <View style={styles.inputContainer}>
                  <TextInput
                    style={styles.input}
                    placeholder="Title *"
                    placeholderTextColor="#B2BEB5"
                    value={activeCard.data.title}
                    onChangeText={(value) => setActiveCard({ ...activeCard, data: { ...activeCard.data, title: value } })}
                  />
                </View>
                <View style={styles.inputContainer}>
                  <TextInput
                    style={[styles.input, { height: 100, textAlignVertical: 'top' }]}
                    placeholder="Description *"
                    placeholderTextColor="#B2BEB5"
                    multiline
                    value={activeCard.data.description}
                    onChangeText={(value) => setActiveCard({ ...activeCard, data: { ...activeCard.data, description: value } })}
                  />
                </View>
                <View style={styles.inputContainer}>
                  <TextInput
                    style={styles.input}
                    placeholder="Requested Amount (optional)"
                    placeholderTextColor="#B2BEB5"
                    keyboardType="numeric"
                    value={activeCard.data.requestedAmount}
                    onChangeText={(value) => setActiveCard({ ...activeCard, data: { ...activeCard.data, requestedAmount: value } })}
                  />
                </View>
                <TouchableOpacity
                  style={styles.submitButton}
                  onPress={() => handleUpdateSubmit(activeCard.data)}
                >
                  <Text style={styles.buttonText}>Submit Update</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.hideButton}
                  onPress={() => setActiveCard(null)}
                >
                  <Text style={styles.hideButtonText}>Hide</Text>
                </TouchableOpacity>
              </>
            )}

            {activeCard.type === 'patch' && (
              <>
                <Text style={styles.requestTitle}>Partially Update Emergency (ID: {activeCard.data.id})</Text>
                <View style={styles.inputContainer}>
                  <Picker
                    selectedValue={activeCard.data.emergencyType}
                    onValueChange={(value) => setActiveCard({ ...activeCard, data: { ...activeCard.data, emergencyType: value } })}
                    style={styles.input}
                  >
                    <Picker.Item label="Select issue type" value="" />
                    <Picker.Item label="Medical" value="medical" />
                    <Picker.Item label="Financial" value="financial" />
                    <Picker.Item label="Death" value="death" />
                    <Picker.Item label="Accident" value="accident" />
                    <Picker.Item label="Other" value="other" />
                  </Picker>
                  <View style={styles.checkboxContainer}>
                    <Checkbox
                      value={updateFields.emergencyType}
                      onValueChange={(value) => setUpdateFields({ ...updateFields, emergencyType: value })}
                      color={updateFields.emergencyType ? '#888' : undefined}
                    />
                    <Text style={styles.checkboxLabel}>Update Emergency Type</Text>
                  </View>
                </View>
                <View style={styles.inputContainer}>
                  <TextInput
                    style={styles.input}
                    placeholder="Title *"
                    placeholderTextColor="#888"
                    value={activeCard.data.title}
                    onChangeText={(value) => setActiveCard({ ...activeCard, data: { ...activeCard.data, title: value } })}
                  />
                  <View style={styles.checkboxContainer}>
                    <Checkbox
                      value={updateFields.title}
                      onValueChange={(value) => setUpdateFields({ ...updateFields, title: value })}
                      color={updateFields.title ? '#23A032' : undefined}
                    />
                    <Text style={styles.checkboxLabel}>Update Title</Text>
                  </View>
                </View>
                <View style={styles.inputContainer}>
                  <TextInput
                    style={[styles.input, { height: 100, textAlignVertical: 'top' }]}
                    placeholder="Description *"
                    placeholderTextColor="#888"
                    multiline
                    value={activeCard.data.description}
                    onChangeText={(value) => setActiveCard({ ...activeCard, data: { ...activeCard.data, description: value } })}
                  />
                  <View style={styles.checkboxContainer}>
                    <Checkbox
                      value={updateFields.description}
                      onValueChange={(value) => setUpdateFields({ ...updateFields, description: value })}
                      color={updateFields.description ? '#23A032' : undefined}
                    />
                    <Text style={styles.checkboxLabel}>Update Description</Text>
                  </View>
                </View>
                <View style={styles.inputContainer}>
                  <TextInput
                    style={styles.input}
                    placeholder="Requested Amount (optional)"
                    placeholderTextColor="#888"
                    keyboardType="numeric"
                    value={activeCard.data.requestedAmount}
                    onChangeText={(value) => setActiveCard({ ...activeCard, data: { ...activeCard.data, requestedAmount: value } })}
                  />
                  <View style={styles.checkboxContainer}>
                    <Checkbox
                      value={updateFields.requestedAmount}
                      onValueChange={(value) => setUpdateFields({ ...updateFields, requestedAmount: value })}
                      color={updateFields.requestedAmount ? '#888' : undefined}
                    />
                    <Text style={styles.checkboxLabel}>Update Requested Amount</Text>
                  </View>
                </View>
                <TouchableOpacity
                  style={styles.submitButton}
                  onPress={() => handlePatchSubmit(activeCard.data, updateFields)}
                >
                  <Text style={styles.buttonText}>Submit Partial Update</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.hideButton}
                  onPress={() => setActiveCard(null)}
                >
                  <Text style={styles.hideButtonText}>Hide</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        )}

        <Text style={styles.responseNote}>We'll respond within 24 hours.</Text>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  content: {
    padding: 20,
    paddingBottom: 80,
  },
  header: {
    color: 'black',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 30,
  },
  subHeader: {
    color: 'black',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  inputContainer: {
    borderWidth: 1,
    borderColor: '#B2BEB5',
    borderRadius: 10,
    width: '100%',
    backgroundColor: '#fff',
    marginBottom: 15,
    overflow: 'hidden',
  },
  input: {
    color: '#000',
    height: 50,
    width: '100%',
    fontSize: 14,
    paddingHorizontal: 10,
  },
  checkboxContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
  },
  checkboxLabel: {
    color: '#333',
    marginLeft: 10,
    fontSize: 12,
  },
  submitButton: {
    backgroundColor: '#23A032',
    borderRadius: 5,
    paddingVertical: 10,
    width: '100%',
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 20,
  },
  actionButton: {
    backgroundColor: '#23A032',
    borderRadius: 5,
    paddingVertical: 10,
    width: '100%',
    alignItems: 'center',
    marginBottom: 35,
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  spinner: {
    marginRight: 10,
  },
  requestsContainer: {
    marginBottom: 20,
  },
  requestCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    position: 'relative',
  },
  selectedCard: {
    borderWidth: 2,
    borderColor: '#23A032',
  },
  requestTitle: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
  },
  requestDetail: {
    color: '#333',
    fontSize: 14,
    lineHeight:25,
  },
  hideButton: {
    backgroundColor: '#B22222',
    borderRadius: 5,
    padding: 5,
    marginTop: 10,
    alignSelf: 'flex-end',
  },
  hideButtonText: {
    color: 'white',
    fontSize: 12,
  },
  responseNote: {
    color: '#B2BEB5',
    fontSize: 12,
    textAlign: 'center',
    marginTop: 20,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  errorText: {
    color: 'red',
    fontSize: 12,
    marginBottom: 15,
  },
  iconContainer: {
    flexDirection: 'row',
    position: 'absolute',
    bottom: 10,
    right: 10,
  },
  icon: {
    marginLeft: 10,
  },
  activeCard: {
    marginTop: 20,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
});

export default SupportScreen;