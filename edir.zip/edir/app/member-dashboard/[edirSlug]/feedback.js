import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Modal,
  Platform,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { apiCall } from '../../../src/utils/api';
import { getAccessToken } from '../../../src/utils/token';
import { useLocalSearchParams } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';

const FeedbackScreen = () => {
  const { edirSlug } = useLocalSearchParams();
  const [language, setLanguage] = useState('English');
  const [category, setCategory] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [feedbacks, setFeedbacks] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [editFeedback, setEditFeedback] = useState({ id: null, category: '', subject: '', message: '' });
  const [memberId, setMemberId] = useState(null);

  useEffect(() => {
    console.log('edirSlug from useLocalSearchParams:', edirSlug);
    if (!edirSlug) {
      console.error('No edirSlug provided in route parameters');
      if (Platform.OS === 'web') {
        window.alert('Error: Invalid route. Please navigate to this screen with a valid edirSlug.');
      } else {
        Alert.alert('Error', 'Invalid route. Please navigate to this screen with a valid edirSlug.');
      }
    }

    const fetchUser = async () => {
      try {
        const username = await AsyncStorage.getItem('username');
        const storedMemberId = await AsyncStorage.getItem('member_id');
        console.log('Fetched username from AsyncStorage:', username);
        console.log('Fetched member_id from AsyncStorage:', storedMemberId);
        setCurrentUser(username || 'Unknown User');
        if (storedMemberId) {
          setMemberId(storedMemberId);
        } else {
          if (Platform.OS === 'web') {
            window.alert('Error: Member ID not found');
          } else {
            Alert.alert('Error', 'Member ID not found');
          }
        }
      } catch (error) {
        console.error('Error fetching user data from AsyncStorage:', error.message);
        setCurrentUser('Unknown User');
        if (Platform.OS === 'web') {
          window.alert(`Failed to fetch user data: ${error.message}`);
        } else {
          Alert.alert('Error', `Failed to fetch user data: ${error.message}`);
        }
      }
    };
    fetchUser();
  }, [edirSlug]);

  useEffect(() => {
    if (memberId && edirSlug) {
      fetchFeedbacks();
    }
  }, [memberId, edirSlug]);

  const categoryOptions = [
    { label: 'Select category', value: '' },
    { label: 'General', value: 'general' },
    { label: 'Suggestion', value: 'suggestion' },
    { label: 'Appreciation', value: 'appreciation' },
    { label: 'Complaint', value: 'complaint' },
    { label: 'Other', value: 'other' },
  ];

  const fetchFeedbacks = async () => {
    if (!edirSlug || !memberId) {
      console.error('Skipping feedback fetch: No edirSlug or memberId provided', { edirSlug, memberId });
      if (Platform.OS === 'web') {
        window.alert('Error: No edirSlug or memberId provided.');
      } else {
        Alert.alert('Error', 'No edirSlug or memberId provided.');
      }
      return;
    }
    try {
      console.log(`Fetching feedbacks for edirSlug: ${edirSlug}, memberId: ${memberId}`);
      const data = await apiCall(`/api/${edirSlug}/feedbacks/`, 'GET');
      console.log('Raw feedback data from API:', data);
      const userFeedbacks = Array.isArray(data)
        ? data.filter(feedback => {
            const feedbackMemberId = feedback.member?.id;
            const isMatch = String(feedbackMemberId) === String(memberId);
            console.log(`Feedback ID: ${feedback.id}, member:`, feedback.member, `member_id: ${feedbackMemberId}, matches: ${isMatch}`);
            return isMatch;
          })
        : [];
      console.log('Filtered user feedbacks:', userFeedbacks);
      setFeedbacks(userFeedbacks);
      if (userFeedbacks.length === 0) {
        console.log('No feedbacks found for this user after filtering.');
      }
    } catch (error) {
      console.error('Error fetching feedbacks:', error.message, error);
      if (Platform.OS === 'web') {
        window.alert(`Failed to load feedback history: ${error.message}`);
      } else {
        Alert.alert('Error', `Failed to load feedback history: ${error.message}`);
      }
      setFeedbacks([]);
    }
  };

  const handleSubmit = async () => {
    if (!edirSlug) {
      console.error('No edirSlug provided');
      if (Platform.OS === 'web') {
        window.alert('Error: No edirSlug provided. Please navigate to a valid route.');
      } else {
        Alert.alert('Error', 'No edirSlug provided. Please navigate to a valid route.');
      }
      return;
    }
    if (!category || !subject || !message) {
      console.error('Missing required fields', { category, subject, message });
      if (Platform.OS === 'web') {
        window.alert('Error: Please fill in all required fields');
      } else {
        Alert.alert('Error', 'Please fill in all required fields');
      }
      return;
    }
    if (subject.length > 200) {
      console.error('Subject too long:', subject.length);
      if (Platform.OS === 'web') {
        window.alert('Error: Subject must be 200 characters or less');
      } else {
        Alert.alert('Error', 'Subject must be 200 characters or less');
      }
      return;
    }

    setIsSubmitting(true);
    try {
      const payload = { category, subject, message, member_id: memberId };
      console.log('Submitting feedback with payload:', payload);
      console.log('POST endpoint:', `/api/${edirSlug}/feedbacks/`);
      const token = await getAccessToken();
      console.log('Access token:', token ? 'Present' : 'Missing');
      const response = await apiCall(`/api/${edirSlug}/feedbacks/`, 'POST', payload);
      console.log('Feedback submission response:', response);
      if (Platform.OS === 'web') {
        window.alert('Feedback submitted successfully');
      } else {
        Alert.alert('Success', 'Feedback submitted successfully');
      }
      setCategory('');
      setSubject('');
      setMessage('');
      await fetchFeedbacks();
    } catch (error) {
      console.error('Error submitting feedback:', error.message, error);
      if (Platform.OS === 'web') {
        window.alert(`Failed to submit feedback: ${error.message}`);
      } else {
        Alert.alert('Error', `Failed to submit feedback: ${error.message}`);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSave = async () => {
    if (!edirSlug || !editFeedback.id) {
      console.error('No edirSlug or feedback ID provided');
      if (Platform.OS === 'web') {
        window.alert('Error: Invalid request.');
      } else {
        Alert.alert('Error', 'Invalid request.');
      }
      return;
    }
    if (!editFeedback.category || !editFeedback.subject || !editFeedback.message) {
      console.error('Missing required fields', editFeedback);
      if (Platform.OS === 'web') {
        window.alert('Error: Please fill in all required fields');
      } else {
        Alert.alert('Error', 'Please fill in all required fields');
      }
      return;
    }
    if (editFeedback.subject.length > 200) {
      console.error('Subject too long:', editFeedback.subject.length);
      if (Platform.OS === 'web') {
        window.alert('Error: Subject must be 200 characters or less');
      } else {
        Alert.alert('Error', 'Subject must be 200 characters or less');
      }
      return;
    }

    setIsSubmitting(true);
    try {
      const payload = {
        category: editFeedback.category,
        subject: editFeedback.subject,
        message: editFeedback.message,
      };
      console.log('Updating feedback with payload:', payload);
      console.log('PATCH endpoint:', `/api/${edirSlug}/feedbacks/${editFeedback.id}/`);
      const token = await getAccessToken();
      console.log('Access token:', token ? 'Present' : 'Missing');
      const response = await apiCall(`/api/${edirSlug}/feedbacks/${editFeedback.id}/`, 'PATCH', payload);
      console.log('Feedback update response:', response);
      if (Platform.OS === 'web') {
        window.alert('Feedback updated successfully');
      } else {
        Alert.alert('Success', 'Feedback updated successfully');
      }
      setModalVisible(false);
      setEditFeedback({ id: null, category: '', subject: '', message: '' });
      await fetchFeedbacks();
    } catch (error) {
      console.error('Error updating feedback:', error.message, error);
      if (Platform.OS === 'web') {
        window.alert(`Failed to update feedback: ${error.message}`);
      } else {
        Alert.alert('Error', `Failed to update feedback: ${error.message}`);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (feedbackId) => {
    if (!edirSlug || !feedbackId || !memberId) {
      console.error('No edirSlug, feedback ID, or memberId provided', { edirSlug, feedbackId, memberId });
      if (Platform.OS === 'web') {
        window.alert('Error: Invalid request.');
      } else {
        Alert.alert('Error', 'Invalid request.');
      }
      return;
    }

    console.log('Delete icon clicked for feedback ID:', feedbackId);

    const confirmDelete = Platform.OS === 'web'
      ? window.confirm('Are you sure you want to delete this feedback?')
      : await new Promise((resolve) => {
          Alert.alert(
            'Confirm Delete',
            'Are you sure you want to delete this feedback?',
            [
              {
                text: 'Cancel',
                style: 'cancel',
                onPress: () => {
                  console.log('Delete canceled for feedback ID:', feedbackId);
                  resolve(false);
                },
              },
              {
                text: 'Delete',
                style: 'destructive',
                onPress: () => {
                  console.log('Delete confirmed for feedback ID:', feedbackId);
                  resolve(true);
                },
              },
            ],
            { onDismiss: () => {
              console.log('Alert dismissed for feedback ID:', feedbackId);
              resolve(false);
            }}
          );
        });

    if (!confirmDelete) {
      console.log('Deletion aborted for feedback ID:', feedbackId);
      return;
    }

    console.log('Attempting DELETE with memberId:', memberId);
    let endpoint = `/api/${edirSlug}/feedbacks/${feedbackId}/?member_id=${memberId}`;
    try {
      console.log('Sending DELETE request to:', endpoint);
      const token = await getAccessToken();
      console.log('Access token:', token ? 'Present' : 'Missing');
      if (!token) {
        throw new Error('No access token available');
      }
      await apiCall(endpoint, 'DELETE');
      console.log('Feedback deleted successfully:', feedbackId);
      if (Platform.OS === 'web') {
        window.alert('Feedback deleted successfully');
      } else {
        Alert.alert('Success', 'Feedback deleted successfully');
      }
      await fetchFeedbacks();
    } catch (error) {
      console.error(`Error deleting feedback with endpoint ${endpoint}:`, {
        message: error.message,
        status: error.status || 'N/A',
        response: error.response || 'No response',
      });
      if (error.response?.detail === 'No MemberFeedback matches the given query.') {
        console.log('Retrying with alternative endpoint: /api/${edirSlug}/member-feedbacks/${feedbackId}/');
        try {
          endpoint = `/api/${edirSlug}/member-feedbacks/${feedbackId}/`;
          console.log('Sending DELETE request to:', endpoint);
          await apiCall(endpoint, 'DELETE');
          console.log('Feedback deleted successfully:', feedbackId);
          if (Platform.OS === 'web') {
            window.alert('Feedback deleted successfully');
          } else {
            Alert.alert('Success', 'Feedback deleted successfully');
          }
          await fetchFeedbacks();
        } catch (retryError) {
          console.error(`Error deleting feedback with alternative endpoint ${endpoint}:`, {
            message: retryError.message,
            status: retryError.status || 'N/A',
            response: retryError.response || 'No response',
          });
          if (Platform.OS === 'web') {
            window.alert(`Failed to delete feedback: ${retryError.message}`);
          } else {
            Alert.alert('Error', `Failed to delete feedback: ${retryError.message}`);
          }
        }
      } else {
        if (Platform.OS === 'web') {
          window.alert(`Failed to delete feedback: ${error.message}`);
        } else {
          Alert.alert('Error', `Failed to delete feedback: ${error.message}`);
        }
      }
    }
  };

  const startEditing = (feedback) => {
    setEditFeedback({
      id: feedback.id,
      category: feedback.category,
      subject: feedback.subject,
      message: feedback.message,
    });
    setModalVisible(true);
  };

  const cancelEditing = () => {
    setModalVisible(false);
    setEditFeedback({ id: null, category: '', subject: '', message: '' });
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.header}>Send Feedback</Text>

        {edirSlug ? (
          <>
            <Text style={styles.sectionTitle}>Category</Text>
            <View style={styles.inputContainer}>
              <Picker
                selectedValue={category}
                onValueChange={(value) => {
                  console.log('Selected category:', value);
                  setCategory(value);
                }}
                style={styles.picker}
                itemStyle={styles.pickerItem}
              >
                {categoryOptions.map((option) => (
                  <Picker.Item
                    key={option.value}
                    label={option.label}
                    value={option.value}
                  />
                ))}
              </Picker>
            </View>

            <Text style={styles.sectionTitle}>Subject</Text>
            <View style={styles.inputContainer}>
              <TextInput
                style={styles.input}
                placeholder="Enter subject (max 200 characters)"
                placeholderTextColor="#333333"
                value={subject}
                onChangeText={setSubject}
                maxLength={200}
              />
            </View>

            <Text style={styles.sectionTitle}>Message</Text>
            <View style={styles.inputContainer}>
              <TextInput
                style={[styles.input, { height: 100, textAlignVertical: 'top' }]}
                placeholder="Enter your feedback here"
                placeholderTextColor="#333333"
                multiline
                value={message}
                onChangeText={setMessage}
              />
            </View>

            <Text style={styles.userText}>Current User: {currentUser}</Text>

            <TouchableOpacity
              style={[styles.submitButton, isSubmitting && { opacity: 0.6 }]}
              onPress={handleSubmit}
              disabled={isSubmitting}
            >
              <Text style={styles.buttonText}>
                {isSubmitting ? 'Processing...' : 'Send Feedback'}
              </Text>
            </TouchableOpacity>
          </>
        ) : (
          <Text style={styles.errorText}>
            Error: Please navigate to this screen with a valid edirSlug.
          </Text>
        )}

        <Text style={styles.sectionTitle}>Feedback History</Text>
        {edirSlug && feedbacks.length > 0 ? (
          feedbacks.map((feedback) => (
            <View key={feedback.id} style={styles.feedbackItem}>
              <Text style={styles.feedbackText}>
                <Text style={styles.feedbackLabel}>Category:</Text>{' '}
                {categoryOptions.find(opt => opt.value === feedback.category)?.label || feedback.category}
              </Text>
              <Text style={styles.feedbackText}>
                <Text style={styles.feedbackLabel}>Subject:</Text> {feedback.subject}
              </Text>
              <Text style={styles.feedbackText}>
                <Text style={styles.feedbackLabel}>Message:</Text> {feedback.message}
              </Text>
              <Text style={styles.feedbackText}>
                <Text style={styles.feedbackLabel}>Status:</Text> {feedback.status || 'N/A'}
              </Text>
              <Text style={styles.feedbackText}>
                <Text style={styles.feedbackLabel}>Submitted:</Text>{' '}
                {feedback.created_at
                  ? new Date(feedback.created_at).toLocaleDateString()
                  : 'N/A'}
              </Text>
              {feedback.response && (
                <Text style={styles.feedbackText}>
                  <Text style={styles.feedbackLabel}>Response:</Text> {feedback.response}
                </Text>
              )}
              <View style={styles.feedbackActions}>
                <TouchableOpacity
                  onPress={() => startEditing(feedback)}
                  disabled={isSubmitting}
                >
                  <Ionicons name="create-outline" size={20} color="#23A032" />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => handleDelete(feedback.id)}
                  disabled={isSubmitting}
                >
                  <Ionicons name="trash-outline" size={20} color="#FF6B6B" />
                </TouchableOpacity>
              </View>
            </View>
          ))
        ) : (
          <Text style={styles.feedbackText}>
            {edirSlug ? 'No feedback submitted yet.' : 'Feedback history unavailable without edirSlug.'}
          </Text>
        )}
      </ScrollView>

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={cancelEditing}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Edit Feedback</Text>

            <Text style={styles.sectionTitle}>Category</Text>
            <View style={styles.inputContainer}>
              <Picker
                selectedValue={editFeedback.category}
                onValueChange={(value) => setEditFeedback({ ...editFeedback, category: value })}
                style={styles.modalPicker}
                itemStyle={styles.pickerItem}
              >
                {categoryOptions.map((option) => (
                  <Picker.Item
                    key={option.value}
                    label={option.label}
                    value={option.value}
                  />
                ))}
              </Picker>
            </View>

            <Text style={styles.sectionTitle}>Subject</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="Enter subject (max 200 characters)"
              placeholderTextColor="#333333"
              value={editFeedback.subject}
              onChangeText={(text) => setEditFeedback({ ...editFeedback, subject: text })}
              maxLength={200}
            />

            <Text style={styles.sectionTitle}>Message</Text>
            <TextInput
              style={[styles.modalInput, { height: 100, textAlignVertical: 'top' }]}
              placeholder="Enter your feedback here"
              placeholderTextColor="#333333"
              multiline
              value={editFeedback.message}
              onChangeText={(text) => setEditFeedback({ ...editFeedback, message: text })}
            />

            <TouchableOpacity
              style={[styles.submitButton, isSubmitting && { opacity: 0.6 }]}
              onPress={handleSave}
              disabled={isSubmitting}
            >
              <Text style={styles.buttonText}>
                {isSubmitting ? 'Processing...' : 'Save'}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.cancelButton, isSubmitting && { opacity: 0.6 }]}
              onPress={cancelEditing}
              disabled={isSubmitting}
            >
              <Text style={styles.buttonText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  content: {
    padding: 20,
    paddingBottom: 100,
  },
  header: {
    color: 'black',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 30,
  },
  sectionTitle: {
    color: '#000',
    fontSize: 14,
    marginBottom: 10,
    fontWeight: '600',
  },
  inputContainer: {
    borderWidth: 1,
    borderColor: '#B2BEB5',
    borderRadius: 5,
    width: '100%',
    backgroundColor: '#fff',
    marginBottom: 15,
    overflow: 'hidden',
  },
  input: {
    color: '#000',
    height: 50,
    width: '100%',
    fontSize: 14,
    paddingHorizontal: 10,
  },
  picker: {
    color: '#333333',
    height: 50,
    width: '100%',
    borderRadius: 5,
    borderColor: '#B2BEB5',
    overflow: 'hidden',
  },
  pickerItem: {
    fontSize: 12,
    color: '#000',
  },
  userText: {
    color: '#000',
    fontSize: 12,
    marginBottom: 20,
  },
  submitButton: {
    backgroundColor: '#23A032',
    borderRadius: 10,
    paddingVertical: 10,
    alignItems: 'center',
    alignSelf: 'center',
    width: '100%',
    marginBottom: 10,
  },
  cancelButton: {
    backgroundColor: '#FF6B6B',
    borderRadius: 10,
    paddingVertical: 10,
    alignSelf: 'center',
    width: '100%',
    alignItems: 'center',
    marginBottom: 20,
  },
  languageSelector: {
    position: 'absolute',
    top: 20,
    right: 20,
    zIndex: 1,
  },
  languageText: {
    color: '#23A032',
    fontSize: 14,
    fontWeight: 'bold',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  feedbackItem: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
  },
  feedbackText: {
    color: '#333333',
    fontSize: 12,
    marginBottom: 5,
  },
  feedbackLabel: {
    color: '#333333',
    fontWeight: 'bold',
  },
  errorText: {
    color: '#FF6B6B',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 20,
  },
  feedbackActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 10,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#F5F5F5',
    borderRadius: 10,
    padding: 20,
    width: '90%',
    maxWidth: 400,
  },
  modalTitle: {
    color: 'black',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  modalInput: {
    backgroundColor: '#fff',
    borderColor: '#B2BEB5',
    borderWidth: 1,
    borderRadius: 5,
    color: '#000',
    paddingHorizontal: 10,
    height: 50,
    marginBottom: 10,
    fontSize: 14,
  },
  modalPicker: {
    color: '#000',
    height: 50,
    width: '100%',
  },
});

export default FeedbackScreen;