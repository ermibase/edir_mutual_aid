import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, StyleSheet, ScrollView, Image, TouchableOpacity, SafeAreaView, ActivityIndicator, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams } from 'expo-router';
import { apiCall } from '../../../src/utils/api';
import { getAccessToken } from '../../../src/utils/token';

export default function EventsScreen() {
  const { edirSlug } = useLocalSearchParams();
  const [events, setEvents] = useState([]);
  const [filteredEvents, setFilteredEvents] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [selectedFilter, setSelectedFilter] = useState('All');
  const [showOptions, setShowOptions] = useState(false);
  const [selectedEventId, setSelectedEventId] = useState(null);
  const [note, setNote] = useState('');
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [modalMessage, setModalMessage] = useState('');

  useEffect(() => {
    fetchEvents();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [search, selectedFilter, events]);

  const fetchEvents = async () => {
    try {
      const token = await getAccessToken();
      const data = await apiCall(`/api/${edirSlug}/events/`, 'GET', null, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      console.log(`[${Platform.OS}] Fetched events:`, data);
      setEvents(data);
      setLoading(false);
    } catch (err) {
      console.error(`[${Platform.OS}] Error fetching events:`, err.message);
      setLoading(false);
    }
  };

  const applyFilters = () => {
    const lowerSearch = search.toLowerCase();
    const filtered = events.filter(event =>
      event.title.toLowerCase().includes(lowerSearch) &&
      (selectedFilter === 'All' || event.event_type === selectedFilter)
    );
    setFilteredEvents(filtered);
  };

  const showMessage = (message) => {
    console.log(`[${Platform.OS}] Showing message:`, message);
    if (Platform.OS === 'web') {
      alert(message);
    } else {
      setModalMessage(message);
      setShowMessageModal(true);
    }
  };

  const handleRSVP = async (eventId, status, note) => {
    try {
      const token = await getAccessToken();
      console.log(`[${Platform.OS}] Access Token:`, token ? token.substring(0, 10) + '...' : 'null');
      if (!token) {
        showMessage('No access token found. Please log in again.');
        return;
      }

      // Decode JWT to get user ID
      let userId;
      try {
        if (!token.includes('.') || token.split('.').length !== 3) {
          throw new Error('Invalid JWT format');
        }
        let decodedPayload;
        try {
          decodedPayload = atob(token.split('.')[1]);
        } catch (e) {
          if (typeof Buffer !== 'undefined') {
            decodedPayload = Buffer.from(token.split('.')[1], 'base64').toString('utf-8');
          } else {
            throw new Error('Base64 decoding not supported in this environment');
          }
        }
        const payload = JSON.parse(decodedPayload);
        console.log(`[${Platform.OS}] Decoded Token Payload:`, payload);
        userId = payload.user_id || payload.sub || payload.id;
        if (!userId) {
          throw new Error('User ID not found in token. Available claims: ' + JSON.stringify(payload));
        }
      } catch (decodeError) {
        console.error(`[${Platform.OS}] Error decoding token:`, decodeError.message);
        showMessage('Failed to retrieve user information from token: ' + decodeError.message);
        return;
      }

      // Check for existing attendance
      let attendanceId = null;
      let existingNote = '';
      try {
        console.log(`[${Platform.OS}] Checking existing attendance for user:`, userId);
        const attendances = await apiCall(`/api/${edirSlug}/events/${eventId}/attendances/`, 'GET', null, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        console.log(`[${Platform.OS}] Attendances:`, attendances);
        const userAttendance = Array.isArray(attendances)
          ? attendances.find(att => att.member === userId || att.member === parseInt(userId))
          : null;
        if (userAttendance) {
          attendanceId = userAttendance.id;
          existingNote = userAttendance.note || '';
          console.log(`[${Platform.OS}] Existing attendance found, ID:`, attendanceId, 'Note:', existingNote, 'Status:', userAttendance.status);
        } else {
          console.log(`[${Platform.OS}] No existing attendance found`);
        }
      } catch (getError) {
        console.error(`[${Platform.OS}] Error checking attendance:`, getError.message, 'Status:', getError.status);
        showMessage('Failed to check attendance: ' + getError.message);
        return;
      }

      // Pre-fill note for existing attendance
      if (attendanceId && note === '') {
        setNote(existingNote);
      }

      // Prepare request
      const payload = { status, note };
      console.log(`[${Platform.OS}] RSVP Request Payload:`, payload);

      // Update or create attendance
      try {
        let response;
        if (attendanceId) {
          console.log(`[${Platform.OS}] Sending PATCH to update attendance ID:`, attendanceId);
          try {
            response = await apiCall(`/api/${edirSlug}/events/${eventId}/attendances/${attendanceId}/`, 'PATCH', payload, {
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
              }
            });
          } catch (patchError) {
            console.error(`[${Platform.OS}] PATCH failed:`, patchError.message, 'Status:', patchError.status);
            // Fallback to PUT
            console.log(`[${Platform.OS}] Sending PUT to update attendance ID:`, attendanceId);
            response = await apiCall(`/api/${edirSlug}/events/${eventId}/attendances/${attendanceId}/`, 'PUT', payload, {
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
              }
            });
          }
          console.log(`[${Platform.OS}] Update Response:`, response);
          showMessage(response.message || 'Successfully updated your attendance');
        } else {
          console.log(`[${Platform.OS}] Sending POST to create attendance for user:`, userId);
          response = await apiCall(`/api/${edirSlug}/events/${eventId}/attendances/`, 'POST', payload, {
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`
            }
          });
          console.log(`[${Platform.OS}] Create Response:`, response);
          showMessage(response.message || `Successfully marked as ${status}`);
        }
      } catch (requestError) {
        console.error(`[${Platform.OS}] Request failed:`, requestError.message, 'Status:', requestError.status);
        let errorMessage = requestError.message || 'Failed to process attendance';
        if (requestError.status === 400 && requestError.message.includes('You have already marked for this event')) {
          errorMessage = 'You have already RSVP\'d for this event. Please try updating your status.';
        } else if (requestError.status === 404) {
          errorMessage = 'Attendance record not found. Please try again.';
        } else if (requestError.status === 403) {
          errorMessage = 'You do not have permission to update this attendance record.';
        }
        showMessage(errorMessage);
      }
    } catch (error) {
      console.error(`[${Platform.OS}] Request failed:`, error.message);
      showMessage('Failed to Request: ' + (error.message || 'Unknown error'));
    }
  };

  if (loading) return <ActivityIndicator style={{ marginTop: 50 }} color="#fff" />;

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.header}>Upcoming & Past Events</Text>

      <View style={styles.inputContainer}>
        <Ionicons name="search" size={20} color="#B2BEB5" style={{ marginHorizontal: 10 }} />
        <TextInput
          style={styles.input}
          placeholder="Search events"
          placeholderTextColor="#888"
          value={search}
          onChangeText={setSearch}
        />
      </View>

      <View style={styles.filterContainer}>
        {['All', 'bereavement', 'meeting'].map(filter => (
          <TouchableOpacity
            key={filter}
            style={[styles.filterChip, selectedFilter === filter && { backgroundColor: '#23A032' }]}
            onPress={() => setSelectedFilter(filter)}
          >
            <Text style={styles.filterText}>{filter}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.eventList}>
        {filteredEvents.map((event) => (
          <View key={event.id} style={styles.eventCard}>
            <View style={{ flex: 1 }}>
              <Text style={styles.eventTitle}>{event.title}</Text>
              <Text style={styles.eventTime}>
                {event.start_date || 'TBD'} {event.end_date ? `- ${event.end_date}` : ''}
              </Text>
              <TouchableOpacity
                style={styles.saveAndContinue}
                onPress={() => {
                  setSelectedEventId(event.id);
                  setNote(''); // Reset note initially
                  setShowOptions(true);
                }}
              >
                <Text style={styles.buttonText}>Will You Attend?</Text>
              </TouchableOpacity>
            </View>
            {event.image && <Image source={{ uri: event.image }} style={styles.eventImage} />}
          </View>
        ))}

        {showOptions && (
          <View style={styles.modalOverlay}>
            <View style={styles.modalBox}>
              <Text style={styles.modalTitle}>Will You Attend?</Text>
              <Text style={styles.modalSubtitle}>Will you attend this event?</Text>

              <TextInput
                placeholder="Optional note"
                value={note}
                onChangeText={setNote}
                style={styles.noteInput}
                multiline
              />

              <TouchableOpacity
                style={[styles.modalButton, { backgroundColor: '#23A032' }]}
                onPress={() => {
                  handleRSVP(selectedEventId, 'attending', note);
                  setShowOptions(false);
                  setNote('');
                }}
              >
                <Text style={styles.modalButtonText}>Attending</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.modalButton, { backgroundColor: '#A02323' }]}
                onPress={() => {
                  handleRSVP(selectedEventId, 'not_attending', note);
                  setShowOptions(false);
                  setNote('');
                }}
              >
                <Text style={styles.modalButtonText}>Not Attending</Text>
              </TouchableOpacity>

              <TouchableOpacity onPress={() => setShowOptions(false)} style={{ marginTop: 10 }}>
                <Text style={styles.cancelText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {showMessageModal && (
          <View style={styles.modalOverlay}>
            <View style={styles.modalBox}>
              <Text style={styles.modalTitle}>RSVP Status</Text>
              <Text style={styles.modalSubtitle}>{modalMessage}</Text>
              <TouchableOpacity
                style={[styles.modalButton, { backgroundColor: '#23A032' }]}
                onPress={() => setShowMessageModal(false)}
              >
                <Text style={styles.modalButtonText}>OK</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    paddingHorizontal: 20,
    paddingTop: 40,
  },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'black',
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#B2BEB5',
    borderRadius: 5,
    width: '100%',
    backgroundColor: '#fff',
    marginBottom: 15,
    overflow: 'hidden',
  },
  input: {
    color: '#000',
    height: 50,
    flex: 1,
    fontSize: 12,
    paddingHorizontal: 10,
  },
  filterContainer: {
    flexDirection: 'row',
    marginBottom: 15,
    gap: 10,
  },
  filterChip: {
    backgroundColor: '#bcf5d9',
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 20,
  },
  filterText: {
    color: 'black',
    fontSize: 14,
  },
  eventList: {
    flex: 1,
  },
  eventCard: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 10,
    marginBottom: 15,
    alignItems: 'center',
  },
  eventTitle: {
    color: 'black',
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 5,
  },
  eventTime: {
    color: '#333',
    fontSize: 14,
    marginBottom: 10,
  },
  saveAndContinue: {
    backgroundColor: '#23A032',
    borderRadius: 10,
    paddingVertical: 10,
    width: 150,
    alignItems: 'center',
    alignSelf: 'flex-start',
  },
  buttonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: 'bold',
  },
  eventImage: {
    width: 80,
    height: 80,
    borderRadius: 10,
    marginLeft: 10,
  },
  modalOverlay: {
    position: 'absolute',
    top: 60,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  modalBox: {
    backgroundColor: '#2334',
    padding: 10,
    borderRadius: 12,
    width: '80%',
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 30,
  },
  modalSubtitle: {
    fontSize: 18,
    color: '#fff',
    marginBottom: 20,
    textAlign: 'center',
  },
  modalButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
    marginBottom: 10,
    width: '100%',
    alignItems: 'center',
  },
  modalButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  noteInput: {
    width: '100%',
    height: 60,
    borderColor: '#B2BEB5',
    borderWidth: 1,
    borderRadius:5,
    padding: 10,
    color: 'black',
    backgroundColor: '#fff',
    marginBottom: 20,
  },
  cancelText: {
    color: '#B2BEB5',
    fontSize: 14,
  },
});