import React, { useState, useEffect } from 'react';
import {
  ScrollView, View, Text, TouchableOpacity, ImageBackground, StyleSheet, FlatList, Switch, ActivityIndicator ,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StatusBar } from 'expo-status-bar';
import { apiCall } from '../../../src/utils/api';
import { getAccessToken } from '../../../src/utils/token';


const HomeScreen = () => {
  const router = useRouter();
  const { edirSlug } = useLocalSearchParams();
  const [isDarkTheme, setIsDarkTheme] = useState(false);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [memorial, setMemorial] = useState(null);

  useEffect(() => {
    const loadTheme = async () => {
      const savedTheme = await AsyncStorage.getItem('theme');
      if (savedTheme) {
        setIsDarkTheme(savedTheme === 'dark');
      }
    };
    loadTheme();
  }, []);

   useEffect(() => {
    const fetchEvents = async () => {
      try {
        const data = await apiCall(`/api/${edirSlug}/events/`, 'GET');
        setEvents(data); // Assuming it's an array
      } catch (error) {
        console.error('Failed to fetch events:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchEvents();
  }, [edirSlug]);


  const toggleTheme = async () => {
    const newTheme = !isDarkTheme;
    setIsDarkTheme(newTheme);
    await AsyncStorage.setItem('theme', newTheme ? 'dark' : 'light');
  };

  const quickActions = [
    { id: '1', title: 'Pay Now', icon: 'card', route: `/member-dashboard/${edirSlug}/payment` },
    { id: '2', title: 'RSVP Event', icon: 'calendar', route: `/member-dashboard/${edirSlug}/events` },
    { id: '3', title: 'View Profile', icon: 'person', route: `/member-dashboard/${edirSlug}/profile` },
    { id: '4', title: "    Updates   ", icon: 'notifications', route: `/member-dashboard/${edirSlug}/reminder` },
  ];

  const announcements = [
    { id: '1', title: 'General Meeting', date: 'May 15, 2025', details: 'Annual meeting for all members.' },
    { id: '2', title: 'Payment Reminder', date: 'May 10, 2025', details: 'Q2 payments due soon.' },
  ];

  const archiveItems = [
    { id: '1', title: 'Past Event: New Year Celebration', date: 'Jan 1, 2025' },
    { id: '2', title: 'Contribution: Q1 2025', amount: '$50' },
  ];

  const renderQuickAction = ({ item }) => (
    <TouchableOpacity style={styles.quickAction} onPress={() => router.push(item.route)}>
      <Ionicons name={item.icon} size={24} color={isDarkTheme ? '#000' : '#000'} />
      <Text style={[styles.quickActionText, { color: isDarkTheme ? '#000' : '#000' }]}>
        {item.title}
      </Text>
    </TouchableOpacity>
  );

   if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#23A032" />
      </View>
    );
  }

  return (
     <>
      <StatusBar style="light" backgroundColor="#228B80" />
    <ScrollView style={[styles.container,{ backgroundColor: isDarkTheme ? '#121212' : '#F5F5F5' }]}>
      <View style={styles.header}>
        <Text style={styles.title}>
  <Text style={{ color: isDarkTheme ? '#fff' : '#000' }}>Edir</Text>
  <Text style={{ color: isDarkTheme ? '#38bdf8' : '#38bdf8' }}>Connect</Text>
</Text>
        <View style={styles.themeToggle}>
          <Text style={[styles.themeText, { color: isDarkTheme ? '#fff' : '#000' }]}>
            {isDarkTheme ? 'Dark' : 'Light'} Theme
          </Text>
          <Switch
            value={isDarkTheme}
            onValueChange={toggleTheme}
            trackColor={{ false: '#767577', true: '#B927DE' }}
            thumbColor={isDarkTheme ? '#f4f3f4' : '#f4f3f4'}
          />
        </View>
        <Text style={[styles.welcomeText, { color: isDarkTheme ? '#ccc' : '#333333' }]}>
          Welcome to <Text style={styles.hi}>
  <Text style={{ color: isDarkTheme ? '#fff' : '#000' }}>Edir</Text>
  <Text style={{ color: isDarkTheme ? '#38bdf8' : '#38bdf8' }}>Connect</Text>
</Text> which makes It Easy for you to help and be helped by your Community.
        </Text>
      </View>

      <View style={styles.statsCard}>
        <Text style={styles.statsTitle}>Your Stats</Text>
        <View style={styles.statsRow}>
          <Text style={styles.statsText}>Total Contributions: $150</Text>
          <Text style={styles.statsText}>Events Attended: 3</Text>
        </View>
      </View>

      <View style={styles.quickActions}>
        <Text style={[styles.sectionTitle, { color: isDarkTheme ? '#fff' : '#333333' }]}>Quick Actions</Text>
        <FlatList
          data={quickActions}
          renderItem={renderQuickAction}
          keyExtractor={(item) => item.id}
          horizontal
          showsHorizontalScrollIndicator={false}
        />
      </View>

      <ImageBackground
        source={require('../../../assets/images/payments.jpg')}
        style={styles.section}
        imageStyle={styles.image}>
        <View style={styles.overlay}>
          <Text style={styles.sectionTitle}>Pay</Text>
          <Text style={styles.sectionText}>Get started with making a payment</Text>
          <TouchableOpacity style={styles.button} onPress={() => router.push(`/member-dashboard/${edirSlug}/payment`)}>
            <Text style={styles.buttonText}>Make a payment</Text>
          </TouchableOpacity>
        </View>
      </ImageBackground>

      <ImageBackground
        source={require('../../../assets/images/events.jpg')}
        style={styles.section}
        imageStyle={styles.image}
        resizeMode="cover">
        <View style={styles.overlay}>
          <Text style={styles.sectionTitle}>Events</Text>
          <Text style={styles.sectionText}>Register for an event</Text>
          <Text style={styles.sectionText}>View events</Text>
          <TouchableOpacity style={styles.button} onPress={() => router.push(`/member-dashboard/${edirSlug}/events`)}>
            <Text style={styles.buttonText}>View Events</Text>
          </TouchableOpacity>
        </View>
      </ImageBackground>

      <ImageBackground
        source={require('../../../assets/images/contributions.jpg')}
        style={styles.section}
        imageStyle={styles.image}>
        <View style={styles.overlay}>
          <Text style={styles.sectionTitle}>Contributions</Text>
          <Text style={styles.sectionText}>View your contribution history</Text>
          <Text style={styles.sectionText}>Manage contributions</Text>
          <TouchableOpacity style={styles.button} onPress={() => router.push(`/member-dashboard/${edirSlug}/contribution-history`)}>
            <Text style={styles.buttonText}>Manage Contributions</Text>
          </TouchableOpacity>
        </View>
      </ImageBackground>

      <View style={styles.announcements}>
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: isDarkTheme ? '#fff' : '#333333' }]}>Announcements</Text>
          <TouchableOpacity onPress={() => router.push(`/member-dashboard/${edirSlug}/events`)}>
            <Text style={styles.viewAll}>View All</Text>
          </TouchableOpacity>
        </View>
        
        {events.length === 0 ? (
        <Text>No events available.</Text>
      ) : (
          events.map(event =>(<View key={event.id}
  style={[
    styles.announcementItem,
    { backgroundColor: isDarkTheme ? '#A9A9A9' : '#fff' } // light green vs dark gray
  ]}
>
            <Text style={[styles.announcementTitle, { color: isDarkTheme ? '#000' : '#000' }]}>
              {event.title}
            </Text>
            <Text style={[styles.announcementDetails, { color: isDarkTheme ? '#000' : '#000' }]}>
              {event.details}
            </Text>
            <Text style={[styles.announcementDetails, { color: isDarkTheme ? '#000' : '#000' }]}> {event.start_date || 'TBD'} {event.end_date ? `- ${event.end_date}` : ''}</Text>
          </View>))
        )}
      </View>

      <View style={styles.archive}>
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: isDarkTheme ? '#fff' : '#000'}]}>Archive</Text>
          <TouchableOpacity onPress={() => router.push(`/member-dashboard/${edirSlug}/memorials`)}>
            <Text style={styles.viewAll}>View Archive</Text>
          </TouchableOpacity>
        </View>
        {archiveItems.map((item) => (
          <View key={item.id}
  style={[
    styles.announcementItem,
    { backgroundColor: isDarkTheme ? '#A9A9A9' : '#fff' } // light green vs dark gray
  ]}
>
            <Text style={[styles.archiveTitle, { color: isDarkTheme ? '#000' : '#000' }]}>
              {item.title}
            </Text>
            {item.amount && (
              <Text style={[styles.archiveDetails, { color: isDarkTheme ? '#000' : '#000' }]}>
                Amount: {item.amount}
              </Text>
            )}
            <Text style={[styles.archiveDetails, { color: isDarkTheme ? '#000' : '#000' }]}>{item.date}</Text>
          </View>
        ))}
      </View>

      <View style={styles.activity}>
        <Text style={[styles.sectionTitle, { color: isDarkTheme ? '#fff' : '#000' }]}>Recent Activity</Text>
        <View style={[
    styles.announcementItem,
    { backgroundColor: isDarkTheme ? '#A9A9A9' : '#fff' } // light green vs dark gray
  ]}
>
          <Text style={{ color: isDarkTheme ? '#000' : '#000' }}>
            You paid $50 for the 2nd quarter
          </Text>
          <Text style={styles.activityDate}>Jan 15, 2023</Text>
        </View>
        <View style={[
    styles.announcementItem,
    { backgroundColor: isDarkTheme ? '#A9A9A9' : '#fff' } // light green vs dark gray
  ]}
>
          <Text style={{ color: isDarkTheme ? '#000' : '#000' }}>
            You received $50 for the 2nd quarter
          </Text>
          <Text style={{ color: isDarkTheme ? '#000' : '#000' }}>Jan 15, 2025</Text>
        </View>
      </View>
    </ScrollView>
     </>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor:'#000',
  },
  header: {
    padding: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  themeToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
  },
  themeText: {
    fontSize: 16,
    marginRight: 10,
  },
  welcomeText: {
    fontSize: 16,
    textAlign: 'center',
     lineHeight: 20,
  },
  statsCard: {
    margin: 10,
    padding: 15,
    borderRadius: 10,
    backgroundColor: '#fff',
  },
  statsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statsText: {
    fontSize: 14,
    
  },
  quickActions: {
    padding: 10,
  },
  quickAction: {
    alignItems: 'center',
    marginRight: 15,
    padding: 10,
    borderRadius: 10,
    backgroundColor: '#fff',
  },
  quickActionText: {
    marginTop: 5,
    fontSize: 12,
  
  },
  section: {
    width: '100%',
  aspectRatio: 16 / 9,
    margin: 10,
    borderRadius: 10,
    overflow: 'hidden',
  },
  image: {
    opacity: 0.7,
  },
  overlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
    padding:10,
  },
  sectionText: {
    fontSize: 16,
    color: '#fff',
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#23A032',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
    width:180,
    
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    textAlign: 'center',
  },
  announcements: {
    padding: 20,
  },
  announcementItem: {
    padding: 10,
    backgroundColor: '#fff',
    borderRadius: 10,
    marginBottom: 5,
    marginTop: 10,
  },
  announcementTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color:'#000'
  },
  announcementDetails: {
    fontSize: 14,
    
  },
  announcementDate: {
    fontSize: 24,
    color: 'gray',
  },
  archive: {
    padding: 20,
  },
  archiveItem: {
    padding: 10,
    backgroundColor: '#fff',
    borderRadius: 5,
    marginBottom: 5,
    marginTop: 10,
  },
  archiveTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  archiveDetails: {
    fontSize: 14,
  },
  archiveDate: {
    fontSize: 12,
    color: 'gray',
  },
  activity: {
    padding: 20,
  },
  activityItem: {
    padding: 10,
    backgroundColor: '#A9A9A9',
    borderRadius: 10,
    marginBottom: 5,
  },
  activityDate: {
    fontSize: 14,
    color: 'black',
  },
  viewAll: {
    fontSize: 14,
    color: '#38bdf8',
  },
});
export default HomeScreen;
