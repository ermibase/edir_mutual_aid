import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, ActivityIndicator, Alert } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { apiCall } from '../../../src/utils/api';
import AsyncStorage from '@react-native-async-storage/async-storage';

const PaymentScreen = () => {
  const [allPayments, setAllPayments] = useState([]);
  const [totalPaid, setTotalPaid] = useState(0);
  const [pendingCount, setPendingCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [verifying, setVerifying] = useState({});
  const [verificationData, setVerificationData] = useState({});
  const [summary, setSummary] = useState(null);
  const [penalties, setPenalties] = useState([]);
  const [reminders, setReminders] = useState([]);
  const [selectedDetails, setSelectedDetails] = useState({ type: null, id: null, data: null });
  const [memberId, setMemberId] = useState(null);
  const { edirSlug } = useLocalSearchParams();
  const router = useRouter();

  // Fetch member_id from AsyncStorage on mount
  useEffect(() => {
    const loadMemberId = async () => {
      try {
        const storedMemberId = await AsyncStorage.getItem('member_id');
        console.log('Retrieved member_id from AsyncStorage:', storedMemberId);
        if (storedMemberId) {
          setMemberId(storedMemberId);
        } else {
          console.log('No member_id found in AsyncStorage');
          Alert.alert('Error', 'Member ID not found. Please log in again.', [
            { text: 'OK', onPress: () => router.replace('/auth/sign-in') },
          ]);
          setLoading(false);
        }
      } catch (error) {
        console.error('Failed to load member_id:', error);
        Alert.alert('Error', `Failed to load member ID: ${error.message}`, [
          { text: 'OK', onPress: () => router.replace('/auth/sign-in') },
        ]);
        setLoading(false);
      }
    };
    loadMemberId();
  }, [router]);

  // Validate edirSlug format
  const isValidEdirSlug = (slug) => {
    if (!slug || typeof slug !== 'string' || slug.trim() === '') {
      console.log('Invalid edirSlug:', slug);
      return false;
    }
    const slugPattern = /^[a-z0-9-]+$/;
    return slugPattern.test(slug);
  };

  // Fetch data only when edirSlug and memberId are valid
  useEffect(() => {
    if (!memberId) {
      console.log('Waiting for memberId to be set');
      return;
    }

    const fetchData = async () => {
      if (!isValidEdirSlug(edirSlug)) {
        console.log('Invalid edirSlug:', edirSlug);
        setLoading(false);
        Alert.alert('Error', 'Invalid edir slug. Please log in again.', [
          { text: 'OK', onPress: () => router.replace('/auth/sign-in') },
        ]);
        return;
      }

      setLoading(true);
      try {
        console.log('Fetching payments for member_id:', memberId, 'edirSlug:', edirSlug);
        // Fetch all payments for the member
        const paymentData = await apiCall(`/api/${edirSlug}/payments/?member_id=${memberId}`, 'GET');
        console.log('Raw payments API response:', paymentData);
        const filteredPayments = Array.isArray(paymentData)
          ? paymentData.filter(payment => {
              const memberIdMatch =
                payment.member?.toString() === memberId ||
                payment.member?.id?.toString() === memberId ||
                payment.member_id?.toString() === memberId;
              console.log(`Payment ID: ${payment.id}, member:`, payment.member, 'member_id:', payment.member_id, 'status:', payment.status, 'match:', memberIdMatch);
              return memberIdMatch;
            })
          : [];
        console.log('Filtered payments for member_id:', memberId, filteredPayments.map(p => ({ id: p.id, amount: p.amount, status: p.status })));
        setAllPayments(filteredPayments);

        // Calculate pending count and total paid
        const pendingPayments = filteredPayments.filter(payment => payment.status === 'pending');
        const verifiedPayments = filteredPayments.filter(payment =>
          ['verified', 'complete', 'VERIFIED', 'COMPLETED'].includes(payment.status)
        );
        console.log('Pending payments:', pendingPayments.map(p => ({ id: p.id, amount: p.amount, status: p.status })));
        console.log('Verified payments:', verifiedPayments.map(p => ({ id: p.id, amount: p.amount, status: p.status })));
        setPendingCount(pendingPayments.length);
        let totalPaidAmount = verifiedPayments.reduce(
          (sum, payment) => sum + parseFloat(payment.amount || 0),
          0
        );
        console.log('Calculated total paid for member_id:', memberId, totalPaidAmount);

        // Fetch summary (for debugging and fallback)
        const summaryData = await apiCall(`/api/${edirSlug}/payments/summary/?member_id=${memberId}`, 'GET');
        console.log('Summary API response:', summaryData);
        if (totalPaidAmount === 0 && summaryData.total_amount > 0) {
          console.log('Falling back to summary total_amount due to mismatch');
          totalPaidAmount = parseFloat(summaryData.total_amount || 0);
        }
        console.log('Final total paid for member_id:', memberId, totalPaidAmount);
        setTotalPaid(totalPaidAmount);
        setSummary(summaryData);

        console.log('Comparing total_paid:', {
          frontend_totalPaid: totalPaidAmount,
          backend_summary_total_amount: summaryData.total_amount || 0,
        });

        // Fetch penalties
        const penaltyData = await apiCall(`/api/${edirSlug}/penalties/?member_id=${memberId}`, 'GET');
        console.log('Penalties API response:', penaltyData);
        setPenalties(Array.isArray(penaltyData) ? penaltyData : []);

        // Fetch reminders
        const reminderData = await apiCall(`/api/${edirSlug}/reminders/?member_id=${memberId}`, 'GET');
        console.log('Reminders API response:', reminderData);
        setReminders(Array.isArray(reminderData) ? reminderData : []);
      } catch (error) {
        console.error('Fetch data error:', error);
        Alert.alert('Error', `Failed to fetch data: ${error.message}`);
        setAllPayments([]);
        setTotalPaid(0);
        setPendingCount(0);
        setSummary(null);
        setPenalties([]);
        setReminders([]);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [edirSlug, memberId, router]);

  // Handle verification input changes
  const handleVerificationInput = (paymentId, field, value) => {
    setVerificationData(prev => ({
      ...prev,
      [paymentId]: {
        ...prev[paymentId],
        [field]: value,
      },
    }));
  };

  // Handle payment verification
  const handleVerifyPayment = async (paymentId) => {
    const data = verificationData[paymentId] || {};
    const { reference_id_part, account_suffix } = data;

    if (!reference_id_part?.trim() || !account_suffix?.trim()) {
      Alert.alert('Missing Input', 'Please fill in both Reference ID Part and Account Suffix');
      return;
    }

    setVerifying(prev => ({ ...prev, [paymentId]: true }));
    try {
      await apiCall(`/api/${edirSlug}/payments/${paymentId}/verify/`, 'POST', {
        reference_id_part,
        account_suffix,
      });
      Alert.alert('Success', 'Payment verified successfully');
      // Refetch all payments to update status
      const paymentData = await apiCall(`/api/${edirSlug}/payments/?member_id=${memberId}`, 'GET');
      console.log('Raw payments API response after verification:', paymentData);
      const filteredPayments = Array.isArray(paymentData)
        ? paymentData.filter(payment => {
            const memberIdMatch =
              payment.member?.toString() === memberId ||
              payment.member?.id?.toString() === memberId ||
              payment.member_id?.toString() === memberId;
            console.log(`Payment ID: ${payment.id}, member:`, payment.member, 'member_id:', payment.member_id, 'status:', payment.status, 'match:', memberIdMatch);
            return memberIdMatch;
          })
        : [];
      console.log('Filtered payments after verification:', filteredPayments.map(p => ({ id: p.id, amount: p.amount, status: p.status })));
      setAllPayments(filteredPayments);

      // Update pending count and total paid
      const pendingPayments = filteredPayments.filter(payment => payment.status === 'pending');
      const verifiedPayments = filteredPayments.filter(payment =>
        [ 'pending', 'completed', 'failed', 'refunded'].includes(payment.status)
      );
      console.log('Pending payments after verification:', pendingPayments.map(p => ({ id: p.id, amount: p.amount, status: p.status })));
      console.log('Verified payments after verification:', verifiedPayments.map(p => ({ id: p.id, amount: p.amount, status: p.status })));
      setPendingCount(pendingPayments.length);
      let totalPaidAmount = verifiedPayments.reduce(
        (sum, payment) => sum + parseFloat(payment.amount || 0),
        0
      );
      console.log('Calculated total paid after verification:', totalPaidAmount);

      // Fetch summary for fallback
      const summaryData = await apiCall(`/api/${edirSlug}/payments/summary/?member_id=${memberId}`, 'GET');
      console.log('Summary API response after verification:', summaryData);
      if (totalPaidAmount === 0 && summaryData.total_amount > 0) {
        console.log('Falling back to summary total_amount due to mismatch after verification');
        totalPaidAmount = parseFloat(summaryData.total_amount || 0);
      }
      console.log('Final total paid after verification:', totalPaidAmount);
      setTotalPaid(totalPaidAmount);

      setVerificationData(prev => {
        const { [paymentId]: _, ...rest } = prev;
        return rest;
      });
      if (selectedDetails.type === 'payment' && selectedDetails.id === paymentId) {
        setSelectedDetails({ type: null, id: null, data: null });
      }
    } catch (error) {
      Alert.alert('Error', `Failed to verify payment: ${error.message}`);
    } finally {
      setVerifying(prev => ({ ...prev, [paymentId]: false }));
    }
  };

  // Handle view payment details
  const handleViewPaymentDetails = async (paymentId) => {
    if (selectedDetails.type === 'payment' && selectedDetails.id === paymentId) {
      setSelectedDetails({ type: null, id: null, data: null });
      return;
    }
    try {
      const paymentDetails = await apiCall(`/api/${edirSlug}/payments/${paymentId}/`, 'GET');
      setSelectedDetails({ type: 'payment', id: paymentId, data: paymentDetails });
    } catch (error) {
      Alert.alert('Error', `Failed to fetch payment details: ${error.message}`);
    }
  };

  // Handle view penalty details
  const handleViewPenaltyDetails = async (penaltyId) => {
    if (selectedDetails.type === 'penalty' && selectedDetails.id === penaltyId) {
      setSelectedDetails({ type: null, id: null, data: null });
      return;
    }
    try {
      const penaltyDetails = await apiCall(`/api/${edirSlug}/penalties/${penaltyId}/`, 'GET');
      setSelectedDetails({ type: 'penalty', id: penaltyId, data: penaltyDetails });
    } catch (error) {
      Alert.alert('Error', `Failed to fetch penalty details: ${error.message}`);
    }
  };

  // Handle view reminder details
  const handleViewReminderDetails = async (reminderId) => {
    if (selectedDetails.type === 'reminder' && selectedDetails.id === reminderId) {
      setSelectedDetails({ type: null, id: null, data: null });
      return;
    }
    try {
      const reminderDetails = await apiCall(`/api/${edirSlug}/reminders/${reminderId}/`, 'GET');
      setSelectedDetails({ type: 'reminder', id: reminderId, data: reminderDetails });
    } catch (error) {
      Alert.alert('Error', `Failed to fetch reminder details: ${error.message}`);
    }
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#23A032" />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Payments</Text>

      {/* Payment Summary */}
      <View style={styles.summaryContainer}>
        <Text style={styles.sectionTitle}>Payment Summary</Text>
        <Text style={styles.input}>
          Total Paid: {totalPaid.toFixed(2)} | Pending Payments: {pendingCount}
        </Text>
      </View>

      {/* Payments */}
      <Text style={styles.sectionTitle}>Payments</Text>
      {allPayments.length === 0 ? (
        <Text style={styles.input}>No payments</Text>
      ) : (
        allPayments.map(payment => (
          <View key={payment.id} style={styles.radioContainer}>
            <Text style={styles.radioText}>
              {payment.payment_type_display} - {payment.amount} ({payment.payment_date}) - {payment.status_display}
            </Text>
            <TouchableOpacity onPress={() => handleViewPaymentDetails(payment.id)}>
              <Text style={styles.linkText}>
                {selectedDetails.type === 'payment' && selectedDetails.id === payment.id ? 'Hide Details' : 'View Details'}
              </Text>
            </TouchableOpacity>
            {selectedDetails.type === 'payment' && selectedDetails.id === payment.id && selectedDetails.data && (
              <View style={styles.detailsContainer}>
                <Text style={styles.detailsText}>ID: {selectedDetails.data.id}</Text>
                <Text style={styles.detailsText}>Member: {selectedDetails.data.member_name}</Text>
                <Text style={styles.detailsText}>Edir: {selectedDetails.data.edir_name}</Text>
                <Text style={styles.detailsText}>Amount: {selectedDetails.data.amount}</Text>
                <Text style={styles.detailsText}>Payment Type: {selectedDetails.data.payment_type_display}</Text>
                <Text style={styles.detailsText}>Status: {selectedDetails.data.status_display}</Text>
                <Text style={styles.detailsText}>Date: {selectedDetails.data.payment_date || 'N/A'}</Text>
                <Text style={styles.detailsText}>Transaction Reference: {selectedDetails.data.transaction_reference || 'N/A'}</Text>
                <Text style={styles.detailsText}>Notes: {selectedDetails.data.notes || 'N/A'}</Text>
              </View>
            )}
            {payment.status === 'pending' && (
              <>
                <TextInput
                  style={styles.input}
                  placeholder="Reference ID Part"
                  placeholderTextColor="#888"
                  value={verificationData[payment.id]?.reference_id_part || ''}
                  onChangeText={text => handleVerificationInput(payment.id, 'reference_id_part', text)}
                />
                <TextInput
                  style={styles.input}
                  placeholder="Account Suffix"
                  placeholderTextColor="#888"
                  value={verificationData[payment.id]?.account_suffix || ''}
                  onChangeText={text => handleVerificationInput(payment.id, 'account_suffix', text)}
                />
                <TouchableOpacity
                  style={[styles.button, verifying[payment.id] && styles.disabledButton]}
                  onPress={() => handleVerifyPayment(payment.id)}
                  disabled={verifying[payment.id]}
                >
                  <Text style={styles.buttonText}>
                    {verifying[payment.id] ? 'Verifying...' : 'Verify Payment'}
                  </Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        ))
      )}

      {/* Penalties */}
      <Text style={styles.sectionTitle}>Penalties</Text>
      {penalties.length === 0 ? (
        <Text style={styles.input}>No penalties</Text>
      ) : (
        penalties.map(penalty => (
          <View key={penalty.id} style={styles.radioContainer}>
            <Text style={styles.radioText}>
              {penalty.penalty_type_display} - {penalty.amount} (Due: {penalty.due_date})
            </Text>
            <TouchableOpacity onPress={() => handleViewPenaltyDetails(penalty.id)}>
              <Text style={styles.linkText}>
                {selectedDetails.type === 'penalty' && selectedDetails.id === penalty.id ? 'Hide Details' : 'View Details'}
              </Text>
            </TouchableOpacity>
            {selectedDetails.type === 'penalty' && selectedDetails.id === penalty.id && selectedDetails.data && (
              <View style={styles.detailsContainer}>
                <Text style={styles.detailsText}>ID: {selectedDetails.data.id}</Text>
                <Text style={styles.detailsText}>Member: {selectedDetails.data.member_name}</Text>
                <Text style={styles.detailsText}>Edir: {selectedDetails.data.edir_name}</Text>
                <Text style={styles.detailsText}>Amount: {selectedDetails.data.amount}</Text>
                <Text style={styles.detailsText}>Penalty Type: {selectedDetails.data.penalty_type_display}</Text>
                <Text style={styles.detailsText}>Status: {selectedDetails.data.status_display}</Text>
                <Text style={styles.detailsText}>Due Date: {selectedDetails.data.due_date}</Text>
                <Text style={styles.detailsText}>Reason: {selectedDetails.data.reason}</Text>
              </View>
            )}
          </View>
        ))
      )}

      {/* Reminders */}
      <Text style={styles.sectionTitle}>Reminders</Text>
      {reminders.length === 0 ? (
        <Text style={styles.input}>No reminders</Text>
      ) : (
        reminders.map(reminder => (
          <View key={reminder.id} style={styles.radioContainer}>
            <Text style={styles.radioText}>
              {reminder.subject} ({reminder.scheduled_time})
            </Text>
            <TouchableOpacity onPress={() => handleViewReminderDetails(reminder.id)}>
              <Text style={styles.linkText}>
                {selectedDetails.type === 'reminder' && selectedDetails.id === reminder.id ? 'Hide Details' : 'View Details'}
              </Text>
            </TouchableOpacity>
            {selectedDetails.type === 'reminder' && selectedDetails.id === reminder.id && selectedDetails.data && (
              <View style={styles.detailsContainer}>
                <Text style={styles.detailsText}>ID: {selectedDetails.data.id}</Text>
                <Text style={styles.detailsText}>Edir: {selectedDetails.data.edir_name}</Text>
                <Text style={styles.detailsText}>Subject: {selectedDetails.data.subject}</Text>
                <Text style={styles.detailsText}>Message: {selectedDetails.data.message}</Text>
                <Text style={styles.detailsText}>Reminder Type: {selectedDetails.data.reminder_type_display}</Text>
                <Text style={styles.detailsText}>Status: {selectedDetails.data.status_display}</Text>
                <Text style={styles.detailsText}>Scheduled Time: {selectedDetails.data.scheduled_time}</Text>
                <Text style={styles.detailsText}>Channel: {selectedDetails.data.channel_display}</Text>
              </View>
            )}
          </View>
        ))
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    padding: 20,
  },
  title: {
    color: '#000',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  sectionTitle: {
    color: '#000',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
    marginTop: 20,
  },
  radioContainer: {
    borderWidth: 0,
    borderRadius: 10,
    backgroundColor: '#fff',
    marginBottom: 35,
    padding: 12,
  },
  radioText: {
    color: '#333333',
    fontSize: 14,
    marginBottom: 10,
  },
  linkText: {
    color: '#23A032',
    fontSize: 14,
    marginBottom: 10,
    textDecorationLine: 'underline',
  },
  input: {
    color: '#333333',
    fontSize: 14,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#B2BEB5',
    borderRadius: 5,
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#23A032',
    borderRadius: 5,
    paddingVertical: 10,
    alignItems: 'center',
    alignSelf: 'center',
    width: '100%',
  },
  disabledButton: {
    backgroundColor: '#666',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  detailsContainer: {
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
  },
  detailsText: {
    color: '#333333',
    fontSize: 12,
    marginBottom: 5,
  },
});

export default PaymentScreen;