// app/member-dashboard/[edirSlug]/memorials/index.jsx
import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, ActivityIndicator, TouchableOpacity } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { apiCall } from '../../../../src/utils/api';

const MemorialCard = ({ memorial, onPress }) => (
  <TouchableOpacity onPress={onPress} style={styles.card}>
    <Text style={styles.title}>{memorial.title}</Text>
    <Text style={styles.subtitle}>{memorial.description}</Text>
    <Text style={styles.meta}>Date of Passing: {memorial.date_of_passing}</Text>
    <Text style={styles.meta}>Memorial Date: {memorial.memorial_date}</Text>
    <Text style={styles.link}>View Detail</Text>
  </TouchableOpacity>
);

const MemorialsPage = () => {
  const { edirSlug } = useLocalSearchParams();
  const router = useRouter();
  const [memorials, setMemorials] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchMemorials = async () => {
    try {
      const data = await apiCall(`/api/${edirSlug}/memorials/`);
      setMemorials(data);
    } catch (error) {
      console.error('Error fetching memorials:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMemorials();
  }, [edirSlug]);

  if (loading) {
    return <ActivityIndicator style={{ marginTop: 50 }} size="large" color="#000" />;
  }

  return (
    <ScrollView style={styles.container}>
      {memorials.length === 0 ? (
        <Text style={styles.noData}>No memorials found.</Text>
      ) : (
        memorials.map(memorial => (
          <MemorialCard
            key={memorial.id}
            memorial={memorial}
            onPress={() => router.push(`/member-dashboard/${edirSlug}/memorials/${memorial.id}`)}
          />
        ))
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FAF0E6',
    padding: 16,
  },
  card: {
    backgroundColor: '#f7f7f7',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    marginBottom: 8,
    color: '#333',
  },
  meta: {
    fontSize: 12,
    color: '#555',
  },
  link: {
    marginTop: 10,
    color: '#007AFF',
    fontWeight: '500',
  },
  noData: {
    textAlign: 'center',
    marginTop: 20,
    fontSize: 16,
    color: '#666',
  },
});

export default MemorialsPage;
