import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, ActivityIndicator } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { apiCall } from '../../../../src/utils/api';

const MemorialDetailPage = () => {
  const { edirSlug, id } = useLocalSearchParams();
  const [memorial, setMemorial] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchMemorialDetail = async () => {
    try {
      const data = await apiCall(`/api/${edirSlug}/memorials/${id}/`);
      setMemorial(data);
    } catch (error) {
      console.error('Error fetching memorial detail:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMemorialDetail();
  }, [edirSlug, id]);

  if (loading) {
    return <ActivityIndicator style={{ marginTop: 50 }} size="large" color="#000" />;
  }

  if (!memorial) {
    return <Text style={styles.noData}>Memorial not found.</Text>;
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>{memorial.title}</Text>
        <Text style={styles.label}>Description:</Text>
        <Text style={styles.text}>{memorial.description}</Text>
        <Text style={styles.label}>Date of Passing:</Text>
        <Text style={styles.text}>{memorial.date_of_passing}</Text>
        <Text style={styles.label}>Memorial Date:</Text>
        <Text style={styles.text}>{memorial.memorial_date}</Text>
        <Text style={styles.label}>Location:</Text>
        <Text style={styles.text}>{memorial.location}</Text>
        <Text style={styles.label}>Public:</Text>
        <Text style={styles.text}>{memorial.is_public ? 'Yes' : 'No'}</Text>
        <Text style={styles.label}>Created At:</Text>
        <Text style={styles.text}>{memorial.created_at}</Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    padding: 16,
  },
  card: {
    backgroundColor: '#f7f7f7',
    borderRadius: 12,
    padding: 20,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 10,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginTop: 12,
  },
  text: {
    fontSize: 14,
    color: '#444',
  },
  noData: {
    textAlign: 'center',
    marginTop: 20,
    fontSize: 16,
    color: '#666',
  },
});

export default MemorialDetailPage;
