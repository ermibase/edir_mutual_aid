import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { apiCall } from '../../../src/utils/api'; // Adjust path as needed
import AsyncStorage from '@react-native-async-storage/async-storage';

const ContributionScreen = () => {
  const [activeTab, setActiveTab] = useState('All Payments');
  const [language, setLanguage] = useState('English');
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [userId, setUserId] = useState(null);

  // Get edirSlug from route params
  const { edirSlug } = useLocalSearchParams();

  // Fetch current user's ID from AsyncStorage
  useEffect(() => {
    const fetchUserId = async () => {
      try {
        const memberId = await AsyncStorage.getItem('member_id');
        if (memberId) {
          setUserId(parseInt(memberId)); // Convert to integer to match API's member field
        } else {
          setError('User not authenticated');
        }
      } catch (err) {
        setError('Failed to fetch user data');
        console.error(err);
      }
    };
    fetchUserId();
  }, []);

  // Fetch payments
  useEffect(() => {
    const fetchPayments = async () => {
      if (!userId || !edirSlug) return; // Wait until userId and edirSlug are available
      try {
        setLoading(true);
        const data = await apiCall(`/api/${edirSlug}/payments/`, 'GET');
        // Filter for completed payments belonging to the current user
        const userPayments = data.filter(
          payment => payment.status === 'completed' && payment.member === userId
        );
        setPayments(userPayments);
      } catch (err) {
        setError('Failed to fetch payments');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchPayments();
  }, [edirSlug, userId]);

  // Filter payments based on active tab
  const filteredPayments = () => {
    if (activeTab === 'All Payments') {
      return payments;
    } else if (activeTab === 'Event Contribution') {
      return payments.filter(payment => payment.payment_type === 'contribution');
    } else if (activeTab === 'Monthly Fee') {
      return payments.filter(payment => payment.payment_type === 'monthly');
    }
    return [];
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={[styles.header]}>Contribution</Text>

        {/* Tabs */}
        <View style={styles.tabContainer}>
          {['All Payments', 'Event Fee', 'Monthly Fee'].map((tab) => (
            <TouchableOpacity
              key={tab}
              style={[styles.tabButton, activeTab === tab && styles.activeTab]}
              onPress={() => setActiveTab(tab)}
            >
              <Text style={[styles.tabText, activeTab === tab && styles.activeTabText]}>{tab}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Payment List */}
        <View style={styles.listContainer}>
          {loading ? (
            <Text style={styles.loadingText}>Loading...</Text>
          ) : error ? (
            <Text style={styles.errorText}>{error}</Text>
          ) : filteredPayments().length === 0 ? (
            <Text style={styles.noDataText}>No payments found</Text>
          ) : (
            filteredPayments().map((item, index) => (
              <View key={item.id} style={styles.listItem}>
                <View style={styles.column}>
                  <Text style={styles.name}>Name</Text>
                  <Text style={styles.companyText}>{item.member_name}</Text>
                </View>
                <View style={styles.column}>
                  <Text style={styles.payment}>Payment Type</Text>
                  <Text style={styles.pendingText}>{item.payment_type_display}</Text>
                  
                </View>
                <View style={styles.column}>
                  <Text style={styles.amount}>Amount</Text>
                <Text style={styles.amountText}>{item.amount}</Text>
                </View>
              </View>
            ))
          )}
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  content: {
    padding: 20,
    paddingBottom: 100,
  },
  header: {
    color: 'black',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 25,
  },
  tabContainer: {
    flexDirection: 'row',
    marginBottom: 20,
    backgroundColor: '#bcf5d9',
    borderRadius: 10,
    overflow: 'hidden',
  },
  tabButton: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  activeTab: {
    backgroundColor: '#23A032',
  },
  tabText: {
    color: '#000',
    fontSize: 14,
  },
  activeTabText: {
    color: 'black',
    fontWeight: 'bold',
  },
  listContainer: {
    borderRadius: 5,
    overflow: 'hidden',
    marginBottom: 20,
  },
  listItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#fff',
    padding: 10, // Reduced padding for better mobile fit
    borderWidth: 1,
    borderRadius: 5,
    borderColor: '#fff',
    height: 85,
  },
  column: {
    flex: 1,
    alignItems: 'flex-start',
  },
  name: {
    color: 'black',
    fontSize: 14,
    marginBottom: 4,
    paddingHorizontal: 10, // Reduced to 10 for better alignment
    paddingBottom: 5,
  },
  companyText: {
    color: '#333333',
    fontSize: 14,
    marginBottom: 4,
    paddingHorizontal: 10, // Reduced to 10 for consistency
  },
  payment: {
    color: '#000',
    fontSize: 14,
    paddingHorizontal: 10, // Reduced to 10 for better spacing
    paddingBottom: 5,
    marginBottom: 4,
  },
  amount: {
    color: '#000',
    fontSize: 14,
    paddingHorizontal: 10, // Reduced to 10 for alignment
    paddingBottom: 5,
  },
  amountText: {
    color: '#333333',
    fontSize: 14,
    paddingHorizontal: 10, // Reduced to 10 for consistency
  },
  pendingText: {
    color: '#333333',
    fontSize: 14,
    marginBottom: 4,
    paddingHorizontal: 10, // Reduced to 10 for better fit
  },
  dateText: {
    color: '#000',
    fontSize: 14,
    paddingHorizontal: 10, // Reduced to 10 for consistency
  },
  loadingText: {
    color: '#000',
    fontSize: 16,
    textAlign: 'center',
    padding: 20,
  },
  errorText: {
    color: '#000',
    fontSize: 16,
    textAlign: 'center',
    padding: 20,
  },
  noDataText: {
    color: '#000',
    fontSize: 16,
    textAlign: 'center',
    padding: 20,
  },
});
export default ContributionScreen;